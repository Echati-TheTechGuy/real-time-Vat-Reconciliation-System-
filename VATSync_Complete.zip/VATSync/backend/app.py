"""
app.py — VATSync Flask REST API
Serves both the SME portal and the ZIMRA TaRMS panel
from a single backend on port 5000.

SME endpoints:   /api/sme/...
ZIMRA endpoints: /api/zimra/...
Shared:          /api/health
"""

import os, csv, io, hashlib
from datetime import datetime
from flask import Flask, request, jsonify, Response
from flask_cors import CORS
from dotenv import load_dotenv
import db, core, audit
import openpyxl
from copy import copy

load_dotenv()

app = Flask(__name__)
app.config["SECRET_KEY"] = os.getenv("SECRET_KEY", "vatsync-secret-2026")
CORS(app, resources={r"/api/*": {"origins": "*"}})


# ── HELPERS ───────────────────────────────────────────────────────────────

def _token():
    h = request.headers.get("Authorization", "")
    return h[7:] if h.startswith("Bearer ") else None


def _require_sme():
    t = _token()
    if not t:
        return None, (jsonify({"error": "No token"}), 401)
    s = core.validate_sme_token(t)
    if not s:
        return None, (jsonify({"error": "Session expired. Please log in again."}), 401)
    return s, None


def _require_zimra():
    t = _token()
    if not t:
        return None, (jsonify({"error": "No token"}), 401)
    s = core.validate_zimra_token(t)
    if not s:
        return None, (jsonify({"error": "ZIMRA session expired."}), 401)
    return s, None


# ── SHARED ────────────────────────────────────────────────────────────────

@app.get("/api/health")
def health():
    return jsonify({
        "status": "ok",
        "time"  : datetime.utcnow().isoformat(),
        "mode"  : "sandbox" if os.getenv("FDMS_SANDBOX_MODE","true") == "true"
                  else "production",
        "system": "VATSync"
    })


# ── SME ENDPOINTS ─────────────────────────────────────────────────────────

@app.post("/api/sme/register")
def sme_register():
    import re
    d    = request.get_json() or {}
    tin  = (d.get("tin","") or "").strip()
    name = (d.get("business_name","") or "").strip()
    email= (d.get("email","") or "").strip()
    phone= (d.get("phone","") or "").strip()
    addr = (d.get("address","") or "").strip()

    if not re.match(r"^\d{10}$", tin):
        return jsonify({"error": "TIN must be exactly 10 digits, numbers only"}), 400
    if not name:
        return jsonify({"error": "Business name is required"}), 400
    if db.query("SELECT user_id FROM sme_user WHERE tin_number=?", (tin,)):
        return jsonify({"error": "This TIN is already registered"}), 409

    password = (d.get("password","") or "").strip()
    if not password:
        return jsonify({"error": "Password is required"}), 400
    db.execute(
        "INSERT INTO sme_user (tin_number,business_name,email,phone,address,password) VALUES (?,?,?,?,?,?)",
        (tin, name, email, phone, addr, password)
    )
    row = db.query("SELECT user_id FROM sme_user WHERE tin_number=?", (tin,))
    return jsonify({"message": "Registered successfully", "user_id": row[0]["user_id"]}), 201


@app.post("/api/sme/login")
def sme_login():
    """
    Login requires only TIN + Password.
    Period is optional — defaulted to current month if not provided.
    Period navigation happens on the dashboard without re-login.
    """
    d = request.get_json() or {}
    result, status = core.authenticate_sme(
        d.get("tin",""),
        d.get("password",""),
        d.get("period",""),     # optional — defaults to current month
        ip=request.remote_addr
    )
    return jsonify(result), status


@app.get("/api/sme/dashboard")
def sme_dashboard():
    """
    Returns VAT position for a given period.
    Period is a query parameter — allows navigation without re-login.
    GET /api/sme/dashboard?period=2026-09
    """
    session, err = _require_sme()
    if err: return err

    user_id = session["user_id"]
    tin     = session["tin_number"]
    # Period from query param takes priority; fall back to session period
    period  = request.args.get("period") or session["period"]

    # Validate period format
    import re
    if not re.match(r"^\d{4}-\d{2}$", period):
        return jsonify({"error": "Invalid period format. Use YYYY-MM"}), 400

    records = core.get_vat_records(user_id, tin, period)
    summary = core.calculate_net_vat(user_id, records, period)

    # Compliance flags removed — FDMS data is inherently from VAT-registered suppliers
    flags = []

    # Session remaining time
    t = _token()
    remaining = core.get_session_remaining(t) if t else 0

    return jsonify({
        "business_name"   : session["business_name"],
        "tin_number"      : tin,
        "period"          : period,
        "summary"         : summary,
        "records"         : records,
        "compliance_flags": flags,
        "retrieved_at"    : datetime.utcnow().isoformat(),
        "record_count"    : len(records),
        "session_remaining": remaining,
    })


@app.post("/api/sme/session/extend")
def sme_extend_session():
    """Extend SME session by SESSION_TIMEOUT minutes."""
    t = _token()
    if not t:
        return jsonify({"error": "No token"}), 401
    ok = core.extend_sme_session(t)
    if not ok:
        return jsonify({"error": "Session not found or already expired"}), 401
    remaining = core.get_session_remaining(t)
    return jsonify({"message": "Session extended", "remaining": remaining})


@app.get("/api/sme/comparison")
def sme_comparison():
    """
    Multi-period comparison view.
    Returns VAT summaries for the last 6 periods.
    """
    session, err = _require_sme()
    if err: return err
    data = core.get_multi_period_comparison(
        session["user_id"], session["tin_number"], n_periods=6
    )
    return jsonify({"comparison": data, "tin_number": session["tin_number"],
                    "business_name": session["business_name"]})


@app.get("/api/sme/export/csv")
def sme_export():
    """
    VAT 7 Return XLSX export.
    Fills the official ZIMRA VAT 7 Return Excel template (DTF: 98, Issue No: 3)
    with actual SME data from the VATSync system.
    Parts I–V are populated in-place so the downloaded file is a ready-to-submit
    or ready-to-verify copy of the VAT 7 form.
    """
    session, err = _require_sme()
    if err: return err

    user_id = session["user_id"]
    tin     = session["tin_number"]
    period  = request.args.get("period") or session["period"]

    records = core.get_vat_records(user_id, tin, period)
    summary = core.calculate_net_vat(user_id, records, period)

    # Pull SME address/contact details for Part I
    sme_row = db.query("SELECT * FROM sme_user WHERE tin_number=?", (tin,))
    sme     = sme_row[0] if sme_row else {}

    # ── Computed figures ──────────────────────────────────────────────────────
    t_out_z = float(summary["total_output_zwg"])
    t_in_z  = float(summary["total_input_zwg"])
    t_cr_z  = float(summary["credit_notes_zwg"])
    t_adj   = float(summary.get("adjustments", 0.0))
    bf      = float(summary.get("brought_forward_credit", 0.0))
    net_usd = float(summary["net_vat"])

    # Standard-rated output: gross value = tax / 0.15
    out_recs   = [r for r in records if r["record_type"] == "OUT"]
    out_gross_z = sum(
        float(r.get("zwg_equivalent") or r["tax_amount"] or 0) / 0.15
        for r in out_recs
    )
    # Credit note gross
    cr_recs    = [r for r in records if r["record_type"] == "CREDIT_NOTE"]
    cr_gross_z = sum(
        float(r.get("zwg_equivalent") or r["tax_amount"] or 0) / 0.15
        for r in cr_recs
    )
    # Standard domestic purchases gross
    in_recs    = [r for r in records if r["record_type"] == "IN"]
    in_gross_z = sum(
        float(r.get("zwg_equivalent") or r["tax_amount"] or 0) / 0.15
        for r in in_recs
    )

    # Box 20 = total output tax minus credit note tax
    box20 = t_out_z - t_cr_z
    # Box 32 = total input tax plus adjustments
    box32 = t_in_z + t_adj
    # Net payable (positive = payable, negative = refund)
    net_payable_z = box20 - box32

    # USD figures for Part V
    out_gross_usd = sum(
        float(r["gross_amount"] or 0) / 1.15
        for r in out_recs
    )
    in_gross_usd = sum(
        float(r["gross_amount"] or 0) / 1.15
        for r in in_recs
    )
    out_usd = float(summary["total_output"])
    in_usd  = float(summary["total_input"])

    # ZiG gross for Part V (back-calc from tax)
    out_gross_zig = out_gross_z
    in_gross_zig  = in_gross_z

    # Exchange rate from most recent record
    sample_rate = 1.0
    for r in records:
        if r.get("exchange_rate"):
            sample_rate = float(r["exchange_rate"])
            break

    def dc(value):
        """Split a float into (dollars_int, cents_int) for the form's split columns."""
        v = abs(round(float(value), 2))
        dollars = int(v)
        cents   = round((v - dollars) * 100)
        return dollars, cents

    # ── Load the official VAT 7 template ─────────────────────────────────────
    template_path = os.path.join(
        os.path.dirname(__file__),
        "VAT_7_Return.xlsx"
    )
    # Fallback: allow the template to be alongside app.py or in uploads dir
    if not os.path.exists(template_path):
        # Try the uploads location (dev mode)
        template_path = (
            "/root/.claude/uploads/2223b45c-8812-5599-91d7-47ed9220d353/"
            "3ed8de3b-VAT_7_Return.xlsx"
        )

    wb = openpyxl.load_workbook(template_path)
    ws = wb.active   # Sheet "Table 1"

    def set_cell(row, col, value):
        """Write to a cell (handles merged cells — only top-left anchor is writable)."""
        ws.cell(row=row, column=col).value = value

    # ── PART I — Operator Particulars (rows 4–11) ─────────────────────────────
    # Values go in the merged D:V cell on each row (column 4 = D)
    biz_name = sme.get("business_name") or session.get("business_name", "")
    set_cell(4,  4, biz_name)                             # 1. Name
    set_cell(5,  4, biz_name)                             # 2. Trade Name
    set_cell(6,  4, "")                                   # 3. BP Number (not held)
    set_cell(7,  4, tin)                                  # 4. VAT Number
    set_cell(8,  4, period)                               # 5. Tax Period
    set_cell(9,  4, sme.get("address", ""))               # 6. Physical Address
    set_cell(10, 4, sme.get("email", ""))                 # 7. E-Mail
    set_cell(11, 4, sme.get("phone", ""))                 # 8. Telephone

    # Mark return type — column 13 (M) has the tick/X column for Local Sales Return
    # Row 13 = Local Sales Return checkbox row; set "X" in K13 (col 11)
    set_cell(13, 11, "X")

    # ── PART II — Output Tax (rows 22–36) ────────────────────────────────────
    # Column layout for each line:
    #   G=V-code (pre-filled), J:L=Value Dollars, M:O=Value Cents,
    #   P:S=Output Tax Dollars, T:V=Output Tax Cents
    # Only write to the top-left of each merged range:
    #   Value Dollars → col J (10), Value Cents → col M (13)
    #   Output Tax Dollars → col P (16), Output Tax Cents → col T (20)

    # Row 22 — Line 9: Standard rate (V09)
    d, c = dc(out_gross_z)
    set_cell(22, 10, d); set_cell(22, 13, c)
    d, c = dc(t_out_z)
    set_cell(22, 16, d); set_cell(22, 20, c)

    # Rows 23–29: Lines 10–14a  (zero / blank — standard-rated only in this system)
    # Leave pre-filled zeros/blanks as-is; no override needed.

    # Row 34 — Line 18: Debit/Credit Notes (V30)
    d, c = dc(cr_gross_z)
    set_cell(34, 10, d); set_cell(34, 13, c)
    d, c = dc(t_cr_z)
    set_cell(34, 16, d); set_cell(34, 20, c)

    # Row 36 — Line 20: TOTAL OUTPUT TAX [Box A]
    #   P36:S36 = dollars, T36:V36 = cents
    d, c = dc(box20)
    set_cell(36, 16, d); set_cell(36, 20, c)

    # ── PART III — Input Tax (rows 38–55) ────────────────────────────────────
    # Column layout (from H38:J39 area):
    #   H=V-code (merged H38:J39), K:M=Value Dollars, N:P=Value Cents,
    #   Q:T=Input Tax Dollars, U:W=Input Tax Cents
    # Top-left anchors: Value Dollars → col K (11), Cents → col N (14),
    #                   Tax Dollars → col Q (17),   Tax Cents → col U (21)

    # Row 38/40 — Line 21: Domestic purchases (V39)
    # The row for entering the value is row 40 (A40 has "21a" label but H40=V39 means
    # line 21 data actually sits in rows 38–39 merged area; value cells start row 40)
    # From the template inspection: K40:M40 = Value Dollars, N40:P40 = Cents,
    # Q40:T40 = Input Tax Dollars, U40:W40 = Cents
    d, c = dc(in_gross_z)
    set_cell(40, 11, d); set_cell(40, 14, c)
    d, c = dc(t_in_z)
    set_cell(40, 17, d); set_cell(40, 21, c)

    # Row 55 — Line 30: TOTAL INPUT TAX [Box B]
    # From inspection A55 has the label; value cells follow the same Q/U pattern
    # A55:P55 is merged label; Q55:T55 = dollars, U55:W55 = cents
    d, c = dc(box32)
    set_cell(55, 17, d); set_cell(55, 21, c)

    # ── PART IV — Net Payable (rows 57–66) ───────────────────────────────────
    # Column layout: O57:R57 = Dollars header, S57:V57 = Cents header
    # Each data row: O=dollars (col 15), S=cents (col 19)

    # Row 58 — Line 31: Total Output Tax
    d, c = dc(box20)
    set_cell(58, 15, d); set_cell(58, 19, c)

    # Row 59 — Line 32: Less Total Input Tax
    d, c = dc(box32)
    set_cell(59, 15, d); set_cell(59, 19, c)

    # Row 60 — Line 33: Less VAT Withheld (zero)
    set_cell(60, 15, 0); set_cell(60, 19, 0)

    # Row 61 — Line 34: Amount Payable/Refundable
    d, c = dc(net_payable_z)
    set_cell(61, 15, d); set_cell(61, 19, c)

    # Rows 62–63: Penalty & Interest (zero)
    set_cell(62, 15, 0); set_cell(62, 19, 0)
    set_cell(63, 15, 0); set_cell(63, 19, 0)

    # Row 64 — Line 37: Total
    d, c = dc(net_payable_z)
    set_cell(64, 15, d); set_cell(64, 19, c)

    # Row 65 — Line 38: Brought-forward credit
    # B65:N65 is merged label; value in O65:R65 and S65:V65
    d, c = dc(bf)
    set_cell(65, 15, d); set_cell(65, 19, c)

    # Row 66 — Line 39: Amount Payable/Refundable [V58]
    d, c = dc(net_payable_z)
    set_cell(66, 15, d); set_cell(66, 19, c)

    # ── PART V — Foreign Currency / RTGS (rows 69–71) ────────────────────────
    # Column layout per row:
    #   C:E = USD Value, F:G = V59/V61/V63 USD Tax,
    #   H:K = (more USD value span), L:N = ZiG Value, O:Q = V60/V62/V64 ZiG Tax
    # Top-left anchors: USD Value → C (col 3), USD Tax → F (col 6),
    #                   ZiG Value → L (col 12), ZiG Tax → O (col 15)

    # Row 69 — Line 40: Sales/Adjustments
    set_cell(69, 3,  round(out_gross_usd, 2))   # USD value
    set_cell(69, 6,  round(out_usd,       2))   # V59 USD tax
    set_cell(69, 12, round(out_gross_zig, 2))   # ZiG value
    set_cell(69, 15, round(t_out_z,       2))   # V60 ZiG tax

    # Row 70 — Line 41: Purchases/Adjustments
    set_cell(70, 3,  round(in_gross_usd, 2))    # USD value
    set_cell(70, 6,  round(in_usd,       2))    # V61 USD tax
    set_cell(70, 12, round(in_gross_zig, 2))    # ZiG value
    set_cell(70, 15, round(t_in_z,       2))    # V62 ZiG tax

    # Row 71 — Line 42: Net Amount Refundable/Payable
    set_cell(71, 6,  round(net_usd,       2))   # V63 USD net
    set_cell(71, 15, round(net_payable_z, 2))   # V64 ZiG net

    # ── Signature block (rows 72–75) ─────────────────────────────────────────
    set_cell(72, 1, f"Name: {biz_name}")
    set_cell(75, 1, f"Date: {period}")

    # ── Supporting Schedule sheet ─────────────────────────────────────────────
    if "Transactions" in wb.sheetnames:
        del wb["Transactions"]
    ws2 = wb.create_sheet("Transactions")

    headers = ["Date", "FDMS Ref", "Type", "Counterparty", "TIN",
               "Currency", "Gross (Orig)", "Gross (USD)", "VAT (USD)",
               "Rate (ZiG/USD)", "VAT (ZiG)", "Status", "Posted By"]
    ws2.append(headers)

    for r in records:
        ws2.append([
            r["transaction_date"],
            r["fdms_ref"],
            r["record_type"],
            r["counterparty_name"],
            r.get("counterparty_tin", ""),
            r.get("currency", "USD"),
            round(float(r.get("original_amount") or r["gross_amount"] or 0), 2),
            round(float(r["gross_amount"] or 0), 2),
            round(float(r["tax_amount"] or 0), 2),
            round(float(r.get("exchange_rate") or 1.0), 4),
            round(float(r.get("zwg_equivalent") or r["tax_amount"] or 0), 2),
            r["status"],
            r.get("posted_by", "SYSTEM"),
        ])

    ws2.append([])
    ws2.append([f"Exchange rate applied: 1 USD = {sample_rate:.4f} ZiG (RBZ interbank)"])
    ws2.append(["Generated by VATSync on " + datetime.utcnow().strftime("%Y-%m-%d %H:%M UTC")])

    # ── Serialise and return ──────────────────────────────────────────────────
    audit.record(user_id, session["business_name"],
                 "EXPORT_VAT7", "SUCCESS", f"Period {period}")

    buf = io.BytesIO()
    wb.save(buf)
    buf.seek(0)

    fn = f"VATSync_VAT7_{tin}_{period}.xlsx"
    return Response(
        buf.getvalue(),
        mimetype="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        headers={"Content-Disposition": f'attachment; filename="{fn}"'}
    )


@app.post("/api/sme/logout")
def sme_logout():
    t = _token()
    if t:
        db.execute("DELETE FROM vat_session WHERE token_hash=?",
                   (hashlib.sha256(t.encode()).hexdigest(),))
    return jsonify({"message": "Logged out"}), 200


# ── EXCHANGE RATES ENDPOINTS ──────────────────────────────────────────────

@app.get("/api/rates")
def get_rates():
    """Public — returns recent exchange rates for display."""
    rows = db.query("""
        SELECT * FROM exchange_rates
        ORDER BY rate_date DESC LIMIT 30
    """)
    return jsonify({"rates": rows})


@app.post("/api/zimra/rates")
def post_rate():
    """ZIMRA officer adds or updates an exchange rate."""
    _, err = _require_zimra()
    if err: return err
    d = request.get_json() or {}
    rate_date  = d.get("rate_date","")
    usd_to_zwg = d.get("usd_to_zwg", 0)
    source     = d.get("source","RBZ Official")

    import re
    if not re.match(r"^\d{4}-\d{2}-\d{2}$", rate_date):
        return jsonify({"error": "rate_date must be YYYY-MM-DD"}), 400
    if float(usd_to_zwg) <= 0:
        return jsonify({"error": "usd_to_zwg must be positive"}), 400

    db.execute("""
        INSERT INTO exchange_rates (rate_date, usd_to_zwg, source)
        VALUES (?,?,?)
        ON CONFLICT(rate_date) DO UPDATE SET
            usd_to_zwg = excluded.usd_to_zwg,
            source     = excluded.source
    """, (rate_date, float(usd_to_zwg), source))
    return jsonify({"message": "Rate saved",
                    "rate_date": rate_date, "usd_to_zwg": float(usd_to_zwg)}), 201


# ── ZIMRA ENDPOINTS ───────────────────────────────────────────────────────

@app.post("/api/zimra/login")
def zimra_login():
    d = request.get_json() or {}
    result, status = core.authenticate_zimra(
        d.get("username",""), d.get("password",""),
        ip=request.remote_addr
    )
    return jsonify(result), status


@app.post("/api/zimra/logout")
def zimra_logout():
    t = _token()
    if t:
        db.execute("DELETE FROM zimra_session WHERE token_hash=?",
                   (hashlib.sha256(t.encode()).hexdigest(),))
    return jsonify({"message": "Logged out"}), 200


@app.get("/api/zimra/overview")
def zimra_overview():
    """ZIMRA admin overview — all SME positions for a given period."""
    _, err = _require_zimra()
    if err: return err
    period = request.args.get("period", "")
    if not period:
        now = datetime.utcnow()
        period = f"{now.year}-{now.month:02d}"
    data = core.get_zimra_overview(period)
    return jsonify(data)


@app.get("/api/zimra/businesses")
def zimra_businesses():
    _, err = _require_zimra()
    if err: return err
    rows = db.query("""
        SELECT u.*, COUNT(v.record_id) AS tx_count
        FROM sme_user u
        LEFT JOIN vat_record v ON v.user_id = u.user_id
        GROUP BY u.user_id
        ORDER BY u.business_name
    """)
    return jsonify({"businesses": rows})


@app.post("/api/zimra/transaction")
def zimra_post_transaction():
    session, err = _require_zimra()
    if err: return err
    d = request.get_json() or {}
    result, status = core.post_transaction(session["officer"], d)
    return jsonify(result), status


@app.delete("/api/zimra/transaction/<fdms_ref>")
def zimra_cancel_transaction(fdms_ref):
    session, err = _require_zimra()
    if err: return err
    tin = request.args.get("tin","")
    result, status = core.cancel_transaction(session["officer"], fdms_ref, tin)
    return jsonify(result), status


@app.get("/api/zimra/transactions")
def zimra_get_transactions():
    _, err = _require_zimra()
    if err: return err
    tin    = request.args.get("tin","")
    period = request.args.get("period","")
    if not tin:
        return jsonify({"error": "tin is required"}), 400
    rows = db.query("""
        SELECT v.*, u.business_name
        FROM vat_record v
        JOIN sme_user u ON u.user_id = v.user_id
        WHERE v.tin_number = ?
          AND (? = '' OR v.period = ?)
        ORDER BY v.transaction_date DESC, v.posted_at DESC
    """, (tin, period, period))
    return jsonify({"transactions": rows, "count": len(rows)})


@app.get("/api/zimra/summary/<tin>/<period>")
def zimra_summary(tin, period):
    _, err = _require_zimra()
    if err: return err
    user_rows = db.query("SELECT * FROM sme_user WHERE tin_number=?", (tin,))
    if not user_rows:
        return jsonify({"error": "TIN not found"}), 404
    user    = user_rows[0]
    records = core.get_vat_records(user["user_id"], tin, period)
    summary = core.calculate_net_vat(user["user_id"], records, period)
    flags   = []  # FDMS trust model: all fiscal invoice issuers are VAT-registered
    return jsonify({
        "business"        : user,
        "summary"         : summary,
        "records"         : records,
        "compliance_flags": flags,
        "period"          : period,
    })


@app.get("/api/zimra/audit")
def zimra_audit():
    _, err = _require_zimra()
    if err: return err
    rows = db.query("SELECT * FROM audit_log ORDER BY timestamp DESC LIMIT 200")
    return jsonify({"logs": rows})


if __name__ == "__main__":
    db.init_db()
    print("\n" + "=" * 58)
    print("  VATSync — Real-Time VAT Reconciliation System")
    print("  Backend API:  http://localhost:5000")
    print("  SME Portal:   http://localhost:3000")
    print("  ZIMRA Panel:  http://localhost:3001")
    print("=" * 58 + "\n")
    app.run(debug=True, port=5000)
