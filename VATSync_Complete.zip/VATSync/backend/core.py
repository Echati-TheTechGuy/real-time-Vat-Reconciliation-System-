"""
core.py — Business Logic
Authentication, VAT calculation (dual-currency), transaction posting,
period navigation, session extension. FDMS trust model: all fiscal invoices originate from VAT-registered suppliers.

v2: Dual-currency (USD/ZiG) support, period navigation without re-login,
    brought-forward credit. Compliance checking removed — FDMS data is inherently from VAT-registered suppliers.
"""

import hashlib, secrets, os
from datetime import datetime, timedelta
from decimal import Decimal, ROUND_HALF_UP
import db, audit

SESSION_TIMEOUT = 60   # minutes
VAT_RATE = Decimal("0.15")


# ── HELPERS ───────────────────────────────────────────────────────────────

def _hash(token: str) -> str:
    return hashlib.sha256(token.encode()).hexdigest()


def _new_token() -> str:
    return secrets.token_hex(32)


def _expiry() -> str:
    return (datetime.utcnow() + timedelta(minutes=SESSION_TIMEOUT)).isoformat()


def _period_from_date(d: str) -> str:
    """Derive VAT period (YYYY-MM) from a date string."""
    return d[:7]


def _prior_period(period: str) -> str:
    """Return the period one month before the given period."""
    y, m = int(period[:4]), int(period[5:7])
    m -= 1
    if m == 0:
        m, y = 12, y - 1
    return f"{y}-{m:02d}"


def _zwg(usd_amount: Decimal, rate: float) -> Decimal:
    """Convert USD amount to ZiG using the given RBZ rate."""
    return (usd_amount * Decimal(str(rate))).quantize(
        Decimal("0.01"), rounding=ROUND_HALF_UP
    )


# ── SME AUTHENTICATION ────────────────────────────────────────────────────

def authenticate_sme(tin: str, password: str, period: str = "",
                     ip: str = "") -> tuple:
    """
    Validates SME TIN against the registered user list.
    Period is optional at login — selected on the dashboard after login.
    In sandbox mode any non-empty password is accepted.
    """
    import re
    if not re.match(r"^\d{10}$", tin):
        return {"error": "TIN must be exactly 10 digits, numbers only"}, 400
    if not password:
        return {"error": "Password is required"}, 400

    rows = db.query(
        "SELECT * FROM sme_user WHERE tin_number = ?", (tin,)
    )
    if not rows:
        audit.record(None, tin, "SME_LOGIN", "FAILURE",
                     f"Unknown TIN: {tin}", ip)
        return {"error": "TIN not registered. Please register first."}, 401

    user    = rows[0]
    user_id = user["user_id"]

    # Verify password against stored value
    stored_password = user.get("password") or user.get("password_hash") or ""
    if stored_password != password:
        audit.record(user_id, user["business_name"], "SME_LOGIN", "FAILURE",
                     "Incorrect password", ip)
        return {"error": "Incorrect password"}, 401

    # Default period = current month if not supplied
    if not period:
        now = datetime.utcnow()
        period = f"{now.year}-{now.month:02d}"

    raw = _new_token()
    db.execute("""
        INSERT INTO vat_session
            (user_id, token_hash, period, expiry_time, ip_address)
        VALUES (?,?,?,?,?)
    """, (user_id, _hash(raw), period, _expiry(), ip))

    audit.record(user_id, user["business_name"], "SME_LOGIN", "SUCCESS",
                 f"Period: {period}", ip)

    return {
        "token"        : raw,
        "user_id"      : user_id,
        "business_name": user["business_name"],
        "tin_number"   : tin,
        "period"       : period,
        "expires_in"   : SESSION_TIMEOUT * 60,
    }, 200


def validate_sme_token(token: str) -> dict | None:
    rows = db.query("""
        SELECT s.*, u.tin_number, u.business_name, u.email
        FROM vat_session s
        JOIN sme_user u ON u.user_id = s.user_id
        WHERE s.token_hash = ?
          AND datetime(s.expiry_time) > datetime('now')
    """, (_hash(token),))
    return rows[0] if rows else None


def extend_sme_session(token: str) -> bool:
    """Extend an SME session by SESSION_TIMEOUT minutes from now."""
    h = _hash(token)
    rows = db.query(
        "SELECT session_id FROM vat_session WHERE token_hash = ? "
        "AND datetime(expiry_time) > datetime('now')", (h,)
    )
    if not rows:
        return False
    db.execute(
        "UPDATE vat_session SET expiry_time = ? WHERE token_hash = ?",
        (_expiry(), h)
    )
    return True


def get_session_remaining(token: str) -> int:
    """Return seconds remaining in SME session, or 0 if expired."""
    h = _hash(token)
    rows = db.query(
        "SELECT expiry_time FROM vat_session WHERE token_hash = ?", (h,)
    )
    if not rows:
        return 0
    expiry = datetime.fromisoformat(rows[0]["expiry_time"])
    remaining = (expiry - datetime.utcnow()).total_seconds()
    return max(0, int(remaining))


# ── ZIMRA OFFICER AUTHENTICATION ──────────────────────────────────────────

def authenticate_zimra(username: str, password: str, ip: str = "") -> tuple:
    rows = db.query(
        "SELECT * FROM zimra_officer WHERE username = ? AND password = ?",
        (username, password)
    )
    if not rows:
        audit.record(None, username, "ZIMRA_LOGIN", "FAILURE",
                     "Invalid credentials", ip)
        return {"error": "Invalid ZIMRA credentials"}, 401

    officer = rows[0]
    raw     = _new_token()
    db.execute("""
        INSERT INTO zimra_session
            (token_hash, officer, expiry_time, ip_address)
        VALUES (?,?,?,?)
    """, (_hash(raw), officer["full_name"], _expiry(), ip))

    audit.record(None, officer["full_name"], "ZIMRA_LOGIN", "SUCCESS", "", ip)
    return {
        "token"     : raw,
        "officer"   : officer["full_name"],
        "username"  : username,
        "expires_in": SESSION_TIMEOUT * 60,
    }, 200


def validate_zimra_token(token: str) -> dict | None:
    rows = db.query("""
        SELECT * FROM zimra_session
        WHERE token_hash = ?
          AND datetime(expiry_time) > datetime('now')
    """, (_hash(token),))
    return rows[0] if rows else None


# ── VAT DATA ──────────────────────────────────────────────────────────────

def get_vat_records(user_id: int, tin: str, period: str) -> list:
    """
    Returns all active VAT records for a TIN and period.
    Reads directly from the shared database that ZIMRA posts into.
    """
    return db.query("""
        SELECT * FROM vat_record
        WHERE tin_number = ? AND period = ? AND status = 'ACTIVE'
        ORDER BY transaction_date ASC, posted_at ASC
    """, (tin, period))


def calculate_net_vat(user_id: int, records: list, period: str) -> dict:
    """
    Aggregates all record types and computes net VAT liability
    in both USD and ZiG.

    Net VAT (USD) = Output Tax − Input Tax − Credit Notes + Adjustments
    Net VAT (ZiG) = same formula using zwg_equivalent fields

    Brought-forward credit = prior period's net VAT if it was negative
    (i.e. SME had a refund position — that carries forward as additional input)

    Positive net → SME owes ZIMRA.
    Negative net → SME has a refund position.
    """
    input_recs  = [r for r in records if r["record_type"] == "IN"]
    output_recs = [r for r in records if r["record_type"] == "OUT"]
    credit_recs = [r for r in records if r["record_type"] == "CREDIT_NOTE"]
    adjust_recs = [r for r in records if r["record_type"] == "ADJUSTMENT"]

    def total_usd(lst):
        return sum((Decimal(str(r["tax_amount"])) for r in lst), Decimal("0"))

    def total_zwg(lst):
        return sum((Decimal(str(r.get("zwg_equivalent") or 0)) for r in lst), Decimal("0"))

    t_in   = total_usd(input_recs)
    t_out  = total_usd(output_recs)
    t_cr   = total_usd(credit_recs)
    t_adj  = total_usd(adjust_recs)

    t_in_z  = total_zwg(input_recs)
    t_out_z = total_zwg(output_recs)
    t_cr_z  = total_zwg(credit_recs)

    # Look up brought-forward credit from prior period
    prior = _prior_period(period)
    prior_summary = db.query(
        "SELECT net_vat FROM vat_summary WHERE user_id=? AND period=?",
        (user_id, prior)
    )
    bf_credit = Decimal("0")
    if prior_summary:
        prior_net = Decimal(str(prior_summary[0]["net_vat"]))
        if prior_net < 0:
            bf_credit = abs(prior_net)  # refund carried forward as input credit

    net = (t_out - t_in - t_cr + t_adj - bf_credit).quantize(
        Decimal("0.01"), rounding=ROUND_HALF_UP
    )
    net_z = (t_out_z - t_in_z - t_cr_z).quantize(
        Decimal("0.01"), rounding=ROUND_HALF_UP
    )

    summary = {
        "user_id"              : user_id,
        "period"               : period,
        "total_input"          : float(t_in),
        "total_output"         : float(t_out),
        "credit_notes"         : float(t_cr),
        "adjustments"          : float(t_adj),
        "net_vat"              : float(net),
        "input_count"          : len(input_recs),
        "output_count"         : len(output_recs),
        "credit_count"         : len(credit_recs),
        "adjust_count"         : len(adjust_recs),
        "total_input_zwg"      : float(t_in_z),
        "total_output_zwg"     : float(t_out_z),
        "credit_notes_zwg"     : float(t_cr_z),
        "net_vat_zwg"          : float(net_z),
        "brought_forward_credit": float(bf_credit),
    }
    db.upsert_summary(summary)
    return summary


def get_multi_period_comparison(user_id: int, tin: str, n_periods: int = 6) -> list:
    """
    Returns VAT summaries for the last n_periods months.
    Used for the multi-period comparison view.
    """
    now = datetime.utcnow()
    result = []
    for i in range(n_periods - 1, -1, -1):
        d = datetime(now.year, now.month, 1) - timedelta(days=i * 28)
        period = f"{d.year}-{d.month:02d}"
        records = get_vat_records(user_id, tin, period)
        if records or i == 0:
            summary = calculate_net_vat(user_id, records, period)
            result.append({"period": period, **summary})
    return result


# ── COMPLIANCE FLAGGING ───────────────────────────────────────────────────

def get_compliance_flags(user_id: int, tin: str, period: str) -> list:
    """
    Compliance checking removed.

    Zimbabwe's fiscalisation framework (Statutory Instrument 104 of 2010 and
    subsequent ZIMRA directives) requires a business to hold a valid VAT
    registration number before ZIMRA will issue a fiscal device or approve
    a fiscal operator licence.  This means every transaction captured in FDMS
    has already passed ZIMRA's own registration gate — the counterparty is, by
    definition, a VAT-compliant supplier at the time the fiscal invoice was
    issued.

    The previous matching-rule check (comparing INPUT records against supplier
    OUTPUT records in the same period) is therefore redundant for FDMS-sourced
    data and has been removed to avoid misleading compliance warnings.

    Returns an empty list so that existing callers require no changes.
    """
    return []


def post_transaction(officer_name: str, data: dict) -> tuple:
    """
    ZIMRA officer posts a transaction against a TIN.
    Supports both USD and ZiG transactions.
    For USD transactions: ZiG equivalent computed using RBZ rate on transaction date.
    For ZiG transactions: stored as-is, USD equivalent back-calculated.
    """
    import re, secrets as _s

    tin = (data.get("tin_number") or "").strip()
    if not re.match(r"^\d{10}$", tin):
        return {"error": "TIN must be exactly 10 digits"}, 400

    user_rows = db.query("SELECT * FROM sme_user WHERE tin_number = ?", (tin,))
    if not user_rows:
        return {"error": f"TIN {tin} is not registered in the system"}, 404

    user    = user_rows[0]
    user_id = user["user_id"]

    rec_type    = data.get("record_type", "OUT")
    currency    = (data.get("currency") or "USD").upper()
    gross       = float(data.get("gross_amount", 0))
    tx_date     = data.get("transaction_date",
                           datetime.utcnow().strftime("%Y-%m-%d"))
    cpty_name   = (data.get("counterparty_name") or "").strip()
    cpty_tin    = (data.get("counterparty_tin") or "").strip()
    description = (data.get("description") or "").strip()
    invoice_no  = (data.get("invoice_number") or "").strip()

    if gross <= 0:
        return {"error": "Gross amount must be greater than zero"}, 400
    if not cpty_name:
        return {"error": "Counterparty name is required"}, 400
    if currency not in ("USD", "ZWG"):
        return {"error": "Currency must be USD or ZWG (ZiG)"}, 400

    # Get RBZ rate for the transaction date
    rate = db.get_rate_for_date(tx_date)

    # Calculate VAT at 15% — in the original currency
    vat_amount = float(
        (Decimal(str(gross)) * VAT_RATE / (1 + VAT_RATE)
         ).quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)
    )

    # Convert to the other currency
    if currency == "USD":
        # USD transaction — ZiG equivalent using RBZ rate
        gross_usd      = gross
        vat_usd        = vat_amount
        zwg_equivalent = float(_zwg(Decimal(str(vat_amount)), rate))
    else:
        # ZiG transaction — convert back to USD for reporting
        # VAT in ZiG is the zwg_equivalent; USD is back-calculated
        zwg_equivalent = vat_amount           # the ZiG VAT amount
        vat_usd        = round(vat_amount / rate, 2)   # USD equivalent
        gross_usd      = round(gross / rate, 2)
        vat_amount     = vat_usd              # tax_amount stored in USD
        gross          = gross_usd            # gross_amount stored in USD

    period   = _period_from_date(tx_date)
    prefix   = {"IN":"INV","OUT":"OUT","CREDIT_NOTE":"CN","ADJUSTMENT":"ADJ"}.get(rec_type,"TXN")
    fdms_ref = invoice_no or f"{prefix}-{period.replace('-','')}-{_s.token_hex(3).upper()}"

    db.upsert_record({
        "user_id"         : user_id,
        "tin_number"      : tin,
        "fdms_ref"        : fdms_ref,
        "record_type"     : rec_type,
        "tax_amount"      : vat_amount,
        "gross_amount"    : gross,
        "currency"        : currency,
        "original_amount" : float(data.get("gross_amount", 0)),
        "exchange_rate"   : rate,
        "zwg_equivalent"  : zwg_equivalent,
        "transaction_date": tx_date,
        "counterparty_name": cpty_name,
        "counterparty_tin": cpty_tin,
        "invoice_number"  : fdms_ref,
        "description"     : description,
        "period"          : period,
        "status"          : "ACTIVE",
        "posted_by"       : officer_name,
    })

    audit.record(user_id, officer_name, "POST_TRANSACTION", "SUCCESS",
                 f"{rec_type} {currency} {data.get('gross_amount'):.2f} "
                 f"(rate {rate}) → TIN {tin} ({cpty_name})")

    return {
        "message"       : "Transaction posted successfully",
        "fdms_ref"      : fdms_ref,
        "tin_number"    : tin,
        "business_name" : user["business_name"],
        "record_type"   : rec_type,
        "currency"      : currency,
        "gross_amount"  : float(data.get("gross_amount", 0)),
        "gross_usd"     : gross_usd if currency == "USD" else gross,
        "vat_amount"    : vat_amount,
        "zwg_equivalent": zwg_equivalent,
        "exchange_rate" : rate,
        "period"        : period,
        "posted_by"     : officer_name,
    }, 201


def cancel_transaction(officer_name: str, fdms_ref: str,
                       tin: str) -> tuple:
    rows = db.query(
        "SELECT * FROM vat_record WHERE fdms_ref = ? AND tin_number = ?",
        (fdms_ref, tin)
    )
    if not rows:
        return {"error": "Transaction not found"}, 404

    db.execute(
        "UPDATE vat_record SET status='CANCELLED', posted_at=datetime('now') "
        "WHERE fdms_ref = ? AND tin_number = ?",
        (fdms_ref, tin)
    )
    audit.record(rows[0]["user_id"], officer_name,
                 "CANCEL_TRANSACTION", "SUCCESS",
                 f"Cancelled {fdms_ref} for TIN {tin}")
    return {"message": f"Transaction {fdms_ref} cancelled"}, 200


# ── ZIMRA OVERVIEW DASHBOARD ──────────────────────────────────────────────

def get_zimra_overview(period: str) -> dict:
    """
    Returns an overview of all SME VAT positions for the ZIMRA admin dashboard.
    Shows which businesses owe VAT and which are in a refund position.
    """
    businesses = db.query("SELECT * FROM sme_user ORDER BY business_name")
    overview = []
    total_payable  = Decimal("0")
    total_refunds  = Decimal("0")

    for biz in businesses:
        records = get_vat_records(biz["user_id"], biz["tin_number"], period)
        summary = calculate_net_vat(biz["user_id"], records, period)
        net = Decimal(str(summary["net_vat"]))
        status = "REFUND" if net < 0 else ("NIL" if net == 0 else "PAYABLE")

        if net > 0:
            total_payable += net
        elif net < 0:
            total_refunds += abs(net)

        overview.append({
            "tin_number"   : biz["tin_number"],
            "business_name": biz["business_name"],
            "tx_count"     : len(records),
            "net_vat"      : float(net),
            "net_vat_zwg"  : summary["net_vat_zwg"],
            "status"       : status,
        })

    return {
        "period"        : period,
        "businesses"    : overview,
        "total_payable" : float(total_payable),
        "total_refunds" : float(total_refunds),
        "net_position"  : float(total_payable - total_refunds),
        "business_count": len(businesses),
    }
