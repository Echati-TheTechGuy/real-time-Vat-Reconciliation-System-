"""
db.py — Shared Database
Both the SME portal and the ZIMRA TaRMS panel read and write
from the same SQLite database. Real-time updates possible:
ZIMRA posts a transaction → SME refreshes → appears instantly.

Schema v2: Dual-currency (USD / ZiG) support added.
"""

import sqlite3, os
from datetime import datetime

DB_PATH = os.path.join(os.path.dirname(__file__), "vatreconcile.db")


def get_conn():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode=WAL")
    conn.execute("PRAGMA foreign_keys=ON")
    return conn


def init_db():
    conn = get_conn()
    c = conn.cursor()
    c.executescript("""
        -- SME registered businesses
        CREATE TABLE IF NOT EXISTS sme_user (
            user_id       INTEGER PRIMARY KEY AUTOINCREMENT,
            tin_number    TEXT    UNIQUE NOT NULL,
            business_name TEXT    NOT NULL,
            email         TEXT,
            phone         TEXT,
            address       TEXT,
            password      TEXT    NOT NULL DEFAULT '',
            created_at    TEXT    DEFAULT (datetime('now'))
        );

        -- SME login sessions (period no longer required at login)
        CREATE TABLE IF NOT EXISTS vat_session (
            session_id   INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id      INTEGER NOT NULL,
            token_hash   TEXT    NOT NULL,
            period       TEXT    NOT NULL DEFAULT '',
            expiry_time  TEXT    NOT NULL,
            ip_address   TEXT,
            FOREIGN KEY (user_id) REFERENCES sme_user(user_id)
        );

        -- ZIMRA admin sessions
        CREATE TABLE IF NOT EXISTS zimra_session (
            session_id  INTEGER PRIMARY KEY AUTOINCREMENT,
            token_hash  TEXT    NOT NULL,
            officer     TEXT    NOT NULL,
            expiry_time TEXT    NOT NULL,
            ip_address  TEXT
        );

        -- All VAT transactions — the central shared table
        -- v2: dual-currency columns added
        CREATE TABLE IF NOT EXISTS vat_record (
            record_id          INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id            INTEGER NOT NULL,
            tin_number         TEXT    NOT NULL,
            fdms_ref           TEXT    NOT NULL,
            record_type        TEXT    NOT NULL
                               CHECK(record_type IN ('IN','OUT','CREDIT_NOTE','ADJUSTMENT')),
            tax_amount         REAL    NOT NULL,
            gross_amount       REAL    NOT NULL DEFAULT 0,
            currency           TEXT    NOT NULL DEFAULT 'USD'
                               CHECK(currency IN ('USD','ZWG')),
            original_amount    REAL    NOT NULL DEFAULT 0,
            exchange_rate      REAL    NOT NULL DEFAULT 1.0,
            zwg_equivalent     REAL    NOT NULL DEFAULT 0,
            transaction_date   TEXT    NOT NULL,
            counterparty_name  TEXT    NOT NULL,
            counterparty_tin   TEXT,
            invoice_number     TEXT,
            description        TEXT,
            period             TEXT    NOT NULL,
            status             TEXT    NOT NULL DEFAULT 'ACTIVE'
                               CHECK(status IN ('ACTIVE','CANCELLED','ADJUSTED')),
            posted_by          TEXT    NOT NULL DEFAULT 'SYSTEM',
            posted_at          TEXT    DEFAULT (datetime('now')),
            FOREIGN KEY (user_id) REFERENCES sme_user(user_id),
            UNIQUE(tin_number, fdms_ref)
        );

        -- VAT summary cache — recalculated on each dashboard load
        -- v2: ZiG totals and brought-forward credit added
        CREATE TABLE IF NOT EXISTS vat_summary (
            summary_id            INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id               INTEGER NOT NULL,
            period                TEXT    NOT NULL,
            total_input           REAL    NOT NULL DEFAULT 0,
            total_output          REAL    NOT NULL DEFAULT 0,
            credit_notes          REAL    NOT NULL DEFAULT 0,
            adjustments           REAL    NOT NULL DEFAULT 0,
            net_vat               REAL    NOT NULL DEFAULT 0,
            input_count           INTEGER NOT NULL DEFAULT 0,
            output_count          INTEGER NOT NULL DEFAULT 0,
            total_input_zwg       REAL    NOT NULL DEFAULT 0,
            total_output_zwg      REAL    NOT NULL DEFAULT 0,
            credit_notes_zwg      REAL    NOT NULL DEFAULT 0,
            net_vat_zwg           REAL    NOT NULL DEFAULT 0,
            brought_forward_credit REAL   NOT NULL DEFAULT 0,
            generated_at          TEXT    DEFAULT (datetime('now')),
            FOREIGN KEY (user_id) REFERENCES sme_user(user_id),
            UNIQUE(user_id, period)
        );

        -- RBZ exchange rates (USD -> ZWG) — managed by ZIMRA panel
        CREATE TABLE IF NOT EXISTS exchange_rates (
            rate_id    INTEGER PRIMARY KEY AUTOINCREMENT,
            rate_date  TEXT    NOT NULL UNIQUE,
            usd_to_zwg REAL    NOT NULL,
            source     TEXT    NOT NULL DEFAULT 'RBZ Official',
            created_at TEXT    DEFAULT (datetime('now'))
        );

        -- Full audit trail
        CREATE TABLE IF NOT EXISTS audit_log (
            log_id      INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id     INTEGER,
            actor       TEXT,
            action      TEXT    NOT NULL,
            result      TEXT    NOT NULL,
            detail      TEXT,
            ip_address  TEXT,
            timestamp   TEXT    DEFAULT (datetime('now'))
        );

        -- ZIMRA officer accounts
        CREATE TABLE IF NOT EXISTS zimra_officer (
            officer_id  INTEGER PRIMARY KEY AUTOINCREMENT,
            username    TEXT    UNIQUE NOT NULL,
            password    TEXT    NOT NULL,
            full_name   TEXT    NOT NULL,
            created_at  TEXT    DEFAULT (datetime('now'))
        );
    """)

    # Migrate existing tables — add new columns if they don't exist yet
    migrations = [
        "ALTER TABLE vat_record ADD COLUMN currency TEXT NOT NULL DEFAULT 'USD'",
        "ALTER TABLE vat_record ADD COLUMN original_amount REAL NOT NULL DEFAULT 0",
        "ALTER TABLE vat_record ADD COLUMN exchange_rate REAL NOT NULL DEFAULT 1.0",
        "ALTER TABLE vat_record ADD COLUMN zwg_equivalent REAL NOT NULL DEFAULT 0",
        "ALTER TABLE vat_summary ADD COLUMN total_input_zwg REAL NOT NULL DEFAULT 0",
        "ALTER TABLE vat_summary ADD COLUMN total_output_zwg REAL NOT NULL DEFAULT 0",
        "ALTER TABLE vat_summary ADD COLUMN credit_notes_zwg REAL NOT NULL DEFAULT 0",
        "ALTER TABLE vat_summary ADD COLUMN net_vat_zwg REAL NOT NULL DEFAULT 0",
        "ALTER TABLE vat_summary ADD COLUMN brought_forward_credit REAL NOT NULL DEFAULT 0",
        "ALTER TABLE sme_user ADD COLUMN password TEXT NOT NULL DEFAULT ''",
    ]
    for sql in migrations:
        try:
            c.execute(sql)
        except Exception:
            pass  # Column already exists

    # Seed ZIMRA officer account ONLY — no SME seed data
    c.execute("""
        INSERT OR IGNORE INTO zimra_officer (username, password, full_name)
        VALUES ('zimra_admin','zimra2026','ZIMRA TaRMS Administrator')
    """)

    # Seed representative RBZ exchange rates (USD → ZWG)
    c.executemany("""
        INSERT OR IGNORE INTO exchange_rates (rate_date, usd_to_zwg, source)
        VALUES (?,?,?)
    """, [
        ("2026-07-01", 26.45, "RBZ Official"),
        ("2026-07-02", 26.47, "RBZ Official"),
        ("2026-07-07", 26.52, "RBZ Official"),
        ("2026-07-14", 26.60, "RBZ Official"),
        ("2026-07-21", 26.71, "RBZ Official"),
        ("2026-07-28", 26.85, "RBZ Official"),
        ("2026-08-01", 26.90, "RBZ Official"),
        ("2026-08-04", 26.93, "RBZ Official"),
        ("2026-08-11", 27.02, "RBZ Official"),
        ("2026-08-18", 27.14, "RBZ Official"),
        ("2026-08-25", 27.22, "RBZ Official"),
        ("2026-09-01", 27.30, "RBZ Official"),
        ("2026-09-02", 27.32, "RBZ Official"),
        ("2026-09-08", 27.38, "RBZ Official"),
        ("2026-09-09", 27.40, "RBZ Official"),
        ("2026-09-15", 27.45, "RBZ Official"),
        ("2026-09-22", 27.51, "RBZ Official"),
        ("2026-09-27", 27.55, "RBZ Official"),
    ])

    conn.commit()
    conn.close()
    print("✓  VATSync database initialised at", DB_PATH)


def query(sql, params=()):
    conn = get_conn()
    rows = conn.execute(sql, params).fetchall()
    conn.close()
    return [dict(r) for r in rows]


def execute(sql, params=()):
    conn = get_conn()
    conn.execute(sql, params)
    conn.commit()
    conn.close()


def upsert_record(record: dict):
    conn = get_conn()
    conn.execute("""
        INSERT INTO vat_record
            (user_id, tin_number, fdms_ref, record_type, tax_amount,
             gross_amount, currency, original_amount, exchange_rate,
             zwg_equivalent, transaction_date, counterparty_name,
             counterparty_tin, invoice_number, description,
             period, status, posted_by)
        VALUES
            (:user_id, :tin_number, :fdms_ref, :record_type, :tax_amount,
             :gross_amount, :currency, :original_amount, :exchange_rate,
             :zwg_equivalent, :transaction_date, :counterparty_name,
             :counterparty_tin, :invoice_number, :description,
             :period, :status, :posted_by)
        ON CONFLICT(tin_number, fdms_ref) DO UPDATE SET
            tax_amount      = excluded.tax_amount,
            gross_amount    = excluded.gross_amount,
            currency        = excluded.currency,
            original_amount = excluded.original_amount,
            exchange_rate   = excluded.exchange_rate,
            zwg_equivalent  = excluded.zwg_equivalent,
            status          = excluded.status,
            posted_at       = datetime('now')
    """, record)
    conn.commit()
    conn.close()


def upsert_summary(summary: dict):
    conn = get_conn()
    conn.execute("""
        INSERT INTO vat_summary
            (user_id, period, total_input, total_output,
             credit_notes, adjustments, net_vat,
             input_count, output_count,
             total_input_zwg, total_output_zwg, credit_notes_zwg,
             net_vat_zwg, brought_forward_credit, generated_at)
        VALUES
            (:user_id, :period, :total_input, :total_output,
             :credit_notes, :adjustments, :net_vat,
             :input_count, :output_count,
             :total_input_zwg, :total_output_zwg, :credit_notes_zwg,
             :net_vat_zwg, :brought_forward_credit, datetime('now'))
        ON CONFLICT(user_id, period) DO UPDATE SET
            total_input           = excluded.total_input,
            total_output          = excluded.total_output,
            credit_notes          = excluded.credit_notes,
            adjustments           = excluded.adjustments,
            net_vat               = excluded.net_vat,
            input_count           = excluded.input_count,
            output_count          = excluded.output_count,
            total_input_zwg       = excluded.total_input_zwg,
            total_output_zwg      = excluded.total_output_zwg,
            credit_notes_zwg      = excluded.credit_notes_zwg,
            net_vat_zwg           = excluded.net_vat_zwg,
            brought_forward_credit= excluded.brought_forward_credit,
            generated_at          = excluded.generated_at
    """, summary)
    conn.commit()
    conn.close()


def get_rate_for_date(date_str: str) -> float:
    """
    Returns the RBZ USD→ZWG rate applicable on a given date.
    Uses the most recent rate on or before that date.
    Falls back to 27.30 (approximate September 2026 rate) if no rate found.
    """
    rows = query("""
        SELECT usd_to_zwg FROM exchange_rates
        WHERE rate_date <= ?
        ORDER BY rate_date DESC
        LIMIT 1
    """, (date_str,))
    return rows[0]["usd_to_zwg"] if rows else 27.30
