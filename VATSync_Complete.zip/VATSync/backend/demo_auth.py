"""
demo_auth.py — Authentication Module Demo
Runs live against your Flask backend on http://localhost:5000
and prints styled output matching the dissertation screenshot.

Usage (from backend folder, venv active):
    python demo_auth.py
"""

import requests, json, sys

BASE = "http://localhost:5000/api"

# ANSI colour codes
CYAN    = "\033[96m"
GREEN   = "\033[92m"
RED     = "\033[91m"
YELLOW  = "\033[93m"
DIM     = "\033[2m"
BOLD    = "\033[1m"
RESET   = "\033[0m"

SEP = "=" * 72

def banner(title):
    print(f"\n{DIM}{SEP}{RESET}")
    print(f"{CYAN}  Authentication Module  —  {title}{RESET}")
    print(f"{DIM}{SEP}{RESET}\n")

def check(label, passed, detail=""):
    mark  = f"{GREEN}✔  PASS{RESET}" if passed else f"{RED}✘  FAIL{RESET}"
    print(f"  {CYAN}{label}{RESET}")
    if detail:
        print(f"  {DIM}{detail}{RESET}")
    print(f"  {mark}\n")

def post(path, payload, token=None):
    headers = {"Content-Type": "application/json"}
    if token:
        headers["Authorization"] = f"Bearer {token}"
    try:
        r = requests.post(f"{BASE}{path}", json=payload, headers=headers, timeout=5)
        return r.status_code, r.json()
    except requests.exceptions.ConnectionError:
        print(f"{RED}  ERROR: Cannot connect to {BASE}{RESET}")
        print(f"  Make sure your Flask backend is running:  python app.py\n")
        sys.exit(1)

def get(path, token=None):
    headers = {}
    if token:
        headers["Authorization"] = f"Bearer {token}"
    try:
        r = requests.get(f"{BASE}{path}", headers=headers, timeout=5)
        return r.status_code, r.json()
    except requests.exceptions.ConnectionError:
        print(f"{RED}  ERROR: Cannot connect to {BASE}{RESET}")
        sys.exit(1)


# ── Health check ─────────────────────────────────────────────────────────
banner("Live System Test  —  auth_controller.py")

status, data = get("/health")
print(f"  {YELLOW}System:   VATSync Flask REST API{RESET}")
print(f"  {YELLOW}Endpoint: {BASE}{RESET}")
print(f"  {YELLOW}Mode:     {data.get('mode','unknown').upper()}{RESET}")
print(f"  {YELLOW}Time:     {data.get('time','')}{RESET}\n")
print(f"  {DIM}{'-'*68}{RESET}\n")

token = None
passed = 0
failed = 0

# ── Test 1: Valid login ───────────────────────────────────────────────────
print(f"  {BOLD}TEST-01: Login with valid TIN and password{RESET}")
status, data = post("/sme/login", {"tin_number": "1234567890", "password": "pass"})
ok = status == 200 and "token" in data
check(
    f"POST /api/sme/login  →  HTTP {status}",
    ok,
    f"Response: {json.dumps({k: v for k, v in data.items() if k != 'token'}, indent=4)}"
        if ok else f"Response: {data}"
)
if ok:
    token = data["token"]
    passed += 1
else:
    failed += 1

# ── Test 2: Missing password ──────────────────────────────────────────────
print(f"  {BOLD}TEST-02: Login with missing password{RESET}")
status, data = post("/sme/login", {"tin_number": "1234567890", "password": ""})
ok = status in (400, 401)
check(
    f"POST /api/sme/login  →  HTTP {status}",
    ok,
    f"Error message: \"{data.get('error','')}\""
)
passed += ok; failed += (not ok)

# ── Test 3: Invalid TIN format ────────────────────────────────────────────
print(f"  {BOLD}TEST-03: Login with invalid TIN format (not 10 digits){RESET}")
status, data = post("/sme/login", {"tin_number": "ABC123", "password": "pass"})
ok = status in (400, 401)
check(
    f"POST /api/sme/login  →  HTTP {status}",
    ok,
    f"Error message: \"{data.get('error','')}\""
)
passed += ok; failed += (not ok)

# ── Test 4: Unregistered TIN ──────────────────────────────────────────────
print(f"  {BOLD}TEST-04: Login with unregistered TIN{RESET}")
status, data = post("/sme/login", {"tin_number": "0000000000", "password": "pass"})
ok = status in (400, 401)
check(
    f"POST /api/sme/login  →  HTTP {status}",
    ok,
    f"Error message: \"{data.get('error','')}\""
)
passed += ok; failed += (not ok)

# ── Test 5: Token validation (protected endpoint) ─────────────────────────
print(f"  {BOLD}TEST-05: Access protected endpoint with valid session token{RESET}")
if token:
    status, data = get("/sme/vat-data", token=token)
    ok = status in (200, 400)   # 200=data, 400=no period yet — both mean token accepted
    check(
        f"GET /api/sme/vat-data  →  HTTP {status}",
        ok,
        "Token accepted by server — session is active"
    )
else:
    check("GET /api/sme/vat-data", False, "Skipped — no token from TEST-01")
    ok = False
passed += ok; failed += (not ok)

# ── Test 6: Access protected endpoint without token ───────────────────────
print(f"  {BOLD}TEST-06: Access protected endpoint with NO token{RESET}")
status, data = get("/sme/vat-data")
ok = status == 401
check(
    f"GET /api/sme/vat-data (no token)  →  HTTP {status}",
    ok,
    f"Error message: \"{data.get('error','')}\""
)
passed += ok; failed += (not ok)

# ── Summary ───────────────────────────────────────────────────────────────
total = passed + failed
print(f"  {DIM}{'-'*68}{RESET}")
print(f"\n  Ran {total} authentication tests.")
colour = GREEN if failed == 0 else RED
print(f"  {colour}{BOLD}{'OK' if failed == 0 else 'FAILED'}  —  {passed} passed, {failed} failed{RESET}\n")
print(f"{DIM}{SEP}{RESET}\n")
