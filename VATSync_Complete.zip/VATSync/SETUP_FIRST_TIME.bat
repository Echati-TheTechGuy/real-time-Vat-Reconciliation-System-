@echo off
echo ============================================================
echo   VATSync -- First-Time Setup
echo   Run this ONCE on any new machine
echo ============================================================
echo.
echo This will install Python packages and Node.js dependencies.
echo Make sure you have internet access before continuing.
echo.
pause

echo.
echo [1/3] Setting up Python virtual environment and packages...
cd /d %~dp0backend
python -m venv venv
call venv\Scripts\activate
pip install -r requirements.txt
if errorlevel 1 (
    echo ERROR: Python setup failed. Make sure Python 3.10+ is installed.
    pause
    exit /b 1
)
echo Backend setup complete.
echo.

echo [2/3] Installing SME frontend packages...
cd /d %~dp0sme-frontend
npm install
if errorlevel 1 (
    echo ERROR: SME npm install failed. Make sure Node.js 18+ is installed.
    pause
    exit /b 1
)
echo SME frontend setup complete.
echo.

echo [3/3] Installing ZIMRA frontend packages...
cd /d %~dp0zimra-frontend
npm install
if errorlevel 1 (
    echo ERROR: ZIMRA npm install failed.
    pause
    exit /b 1
)
echo ZIMRA frontend setup complete.
echo.

echo ============================================================
echo   Setup complete! You can now run START_VATSYNC.bat
echo   to launch the system.
echo ============================================================
pause
