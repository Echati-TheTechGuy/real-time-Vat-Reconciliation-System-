import{useState,useEffect,useCallback,useRef}from"react";
const API="http://localhost:5000/api/sme";
const fmt=n=>typeof n==="number"?n.toLocaleString("en-US",{minimumFractionDigits:2,maximumFractionDigits:2}):"0.00";
const currentPeriod=()=>{const d=new Date();return`${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,"0")}`};
const periodList=()=>{const l=[];const n=new Date();for(let i=0;i<12;i++){const d=new Date(n.getFullYear(),n.getMonth()-i,1);l.push(`${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,"0")}`)}return l};
const prevPeriod=p=>{if(!p)return currentPeriod();const[y,m]=p.split("-").map(Number);if(m===1)return`${y-1}-12`;return`${y}-${String(m-1).padStart(2,"0")}`};
const nextPeriod=p=>{if(!p)return currentPeriod();const[y,m]=p.split("-").map(Number);if(m===12)return`${y+1}-01`;return`${y}-${String(m+1).padStart(2,"0")}`};
const fmtTime=s=>{const m=Math.floor(s/60),sc=s%60;return`${m}:${String(sc).padStart(2,"0")}`};
const validateTIN=t=>{if(!t)return"TIN is required";if(!/^\d+$/.test(t))return"Numbers only";if(t.length!==10)return`Must be 10 digits (${t.length} entered)`;return""};
const inp={width:"100%",padding:"10px 12px",fontSize:14,border:"1.5px solid #d0dce8",borderRadius:6,boxSizing:"border-box",marginTop:4,marginBottom:4,fontFamily:"inherit"};

const SyncIcon=({size=28,color="#fff"})=>(
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round">
    <path d="M23 4v6h-6"/>
    <path d="M1 20v-6h6"/>
    <path d="M3.51 9a9 9 0 0 1 14.85-3.36L23 10M1 14l4.64 4.36A9 9 0 0 0 20.49 15"/>
  </svg>
);

function RegisterScreen({onBack}){
  const[form,setForm]=useState({tin:"",business_name:"",email:"",phone:"",address:""});
  const[tinErr,setTinErr]=useState("");
  const[loading,setLoading]=useState(false);
  const[msg,setMsg]=useState({text:"",ok:false});
  const handleTIN=e=>{const v=e.target.value.replace(/\D/g,"").slice(0,10);setForm({...form,tin:v});setTinErr(v.length>0&&v.length<10?`${v.length}/10 digits`:"")};
  const submit=async e=>{
    e.preventDefault();const err=validateTIN(form.tin);if(err){setTinErr(err);return;}
    setLoading(true);
    try{const r=await fetch(`${API}/register`,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(form)});
    const d=await r.json();
    if(!r.ok){setMsg({text:d.error||"Failed",ok:false});return;}
    setMsg({text:`✅ Registered! TIN ${form.tin} is now active. You can log in.`,ok:true});}
    catch{setMsg({text:"Cannot reach server",ok:false});}
    finally{setLoading(false);}
  };
  return(<div style={{minHeight:"100vh",background:"#f0f6fb",display:"flex",alignItems:"center",justifyContent:"center"}}>
  <div style={{background:"#fff",borderRadius:12,padding:"36px",width:460,boxShadow:"0 4px 24px rgba(0,0,0,.10)"}}>
    <div style={{textAlign:"center",marginBottom:24}}>
      <div style={{display:"flex",alignItems:"center",justifyContent:"center",gap:8,marginBottom:4}}>
        <div style={{background:"#1a4f72",borderRadius:8,padding:6,display:"flex"}}><SyncIcon size={22} color="#fff"/></div>
        <div style={{fontSize:22,fontWeight:700,color:"#1a4f72"}}>VATSync</div>
      </div>
      <div style={{fontSize:13,color:"#666",marginTop:4}}>Register Your Business</div>
    </div>
    {msg.ok?<div style={{background:"#d4edda",border:"1px solid #0f6e56",borderRadius:8,padding:20,textAlign:"center"}}>
      <div style={{color:"#0f6e56",fontWeight:600,marginBottom:16}}>{msg.text}</div>
      <button onClick={onBack} style={{background:"#2E5C7A",color:"#fff",border:"none",padding:"10px 24px",borderRadius:6,cursor:"pointer",fontWeight:600}}>Go to Login</button>
    </div>:
    <form onSubmit={submit}>
      <label style={{fontSize:12,fontWeight:600,color:"#444"}}>Tax Identification Number (TIN) *</label>
      <input style={{...inp,border:tinErr&&!tinErr.includes("/10")?"1.5px solid #c0392b":inp.border}} value={form.tin} onChange={handleTIN} placeholder="10 digits only" maxLength={10} inputMode="numeric" required/>
      <div style={{height:14,fontSize:11,color:tinErr.includes("/10")?"#c17d00":"#c0392b",marginBottom:8}}>{tinErr}{!tinErr&&form.tin.length===10&&<span style={{color:"#0f6e56"}}>✓ Valid TIN format</span>}</div>
      <div style={{display:"flex",gap:2,marginBottom:12}}>{Array.from({length:10}).map((_,i)=><div key={i} style={{flex:1,height:3,borderRadius:2,background:i<form.tin.length?"#0f6e56":"#e0e0e0"}}/>)}</div>
      <label style={{fontSize:12,fontWeight:600,color:"#444"}}>Business Name *</label>
      <input style={{...inp,marginBottom:12}} value={form.business_name} onChange={e=>setForm({...form,business_name:e.target.value})} placeholder="e.g. Chatikobo Traders (Pvt) Ltd" required/>
      <label style={{fontSize:12,fontWeight:600,color:"#444"}}>Email Address</label>
      <input style={{...inp,marginBottom:12}} type="email" value={form.email} onChange={e=>setForm({...form,email:e.target.value})} placeholder="accounts@yourbusiness.co.zw"/>
      <label style={{fontSize:12,fontWeight:600,color:"#444"}}>Phone Number</label>
      <input style={{...inp,marginBottom:12}} value={form.phone} onChange={e=>setForm({...form,phone:e.target.value})} placeholder="e.g. 0772000001"/>
      <label style={{fontSize:12,fontWeight:600,color:"#444"}}>Business Address</label>
      <input style={{...inp,marginBottom:20}} value={form.address} onChange={e=>setForm({...form,address:e.target.value})} placeholder="e.g. 45 Samora Machel Ave, Harare"/>
      {msg.text&&!msg.ok&&<div style={{background:"#fde8e8",border:"1px solid #c0392b",borderRadius:6,padding:"10px 12px",fontSize:13,color:"#c0392b",marginBottom:14}}>{msg.text}</div>}
      <button type="submit" disabled={loading||form.tin.length!==10} style={{width:"100%",padding:12,background:form.tin.length===10?"#0f6e56":"#aaa",color:"#fff",border:"none",borderRadius:6,fontSize:14,fontWeight:600,cursor:form.tin.length===10?"pointer":"not-allowed",marginBottom:10}}>
        {loading?"Registering...":"Register My Business"}
      </button>
      <button type="button" onClick={onBack} style={{width:"100%",padding:12,background:"transparent",color:"#2E5C7A",border:"1.5px solid #2E5C7A",borderRadius:6,fontSize:14,fontWeight:600,cursor:"pointer"}}>Back to Login</button>
    </form>}
  </div>
  </div>)
}

function LoginScreen({onLogin,onRegister}){
  const[tin,setTin]=useState("");
  const[pwd,setPwd]=useState("");
  const[loading,setLoading]=useState(false);
  const[error,setError]=useState("");
  const[tinErr,setTinErr]=useState("");
  const handleTIN=e=>{const v=e.target.value.replace(/\D/g,"").slice(0,10);setTin(v);if(v.length>0&&v.length<10)setTinErr(`${v.length}/10`);else setTinErr("")};
  const submit=async e=>{
    e.preventDefault();const err=validateTIN(tin);if(err){setTinErr(err);return;}
    setLoading(true);setError("");
    try{const r=await fetch(`${API}/login`,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({tin,password:pwd})});
    const d=await r.json();
    if(!r.ok){setError(d.error||"Login failed");return;}
    onLogin(d.token,d.business_name,tin,d.period||currentPeriod());}
    catch{setError("Cannot reach server. Is the backend running?");}
    finally{setLoading(false);}
  };
  return(<div style={{minHeight:"100vh",background:"#f0f6fb",display:"flex",alignItems:"center",justifyContent:"center"}}>
  <div style={{background:"#fff",borderRadius:12,padding:"40px 36px",width:420,boxShadow:"0 4px 24px rgba(0,0,0,.10)"}}>
    <div style={{textAlign:"center",marginBottom:28}}>
      <div style={{display:"flex",alignItems:"center",justifyContent:"center",gap:10,marginBottom:6}}>
        <div style={{background:"#1a4f72",borderRadius:10,padding:"8px 10px",display:"flex"}}><SyncIcon size={26} color="#fff"/></div>
        <div style={{fontSize:26,fontWeight:700,color:"#1a4f72"}}>VATSync</div>
      </div>
      <div style={{fontSize:13,color:"#666"}}>SME Real-Time VAT Dashboard</div>
      <div style={{fontSize:11,color:"#888",marginTop:2}}>Integrated with ZIMRA TaRMS</div>
    </div>
    <form onSubmit={submit}>
      <label style={{fontSize:12,fontWeight:600,color:"#444"}}>Tax Identification Number (TIN)</label>
      <input style={{...inp,marginBottom:4,border:tinErr?"1.5px solid #c0392b":inp.border}} value={tin} onChange={handleTIN} placeholder="Enter your 10-digit TIN" maxLength={10} inputMode="numeric" required/>
      {tinErr?<div style={{fontSize:11,color:"#c0392b",marginBottom:10}}>{tinErr}</div>:<div style={{height:14,marginBottom:4}}/>}
      <label style={{fontSize:12,fontWeight:600,color:"#444"}}>TaRMS Password</label>
      <input style={{...inp,marginBottom:22}} type="password" value={pwd} onChange={e=>setPwd(e.target.value)} placeholder="Your TaRMS password" required/>
      {error&&<div style={{background:"#fde8e8",border:"1px solid #c0392b",borderRadius:6,padding:"10px 12px",fontSize:13,color:"#c0392b",marginBottom:14}}>{error}</div>}
      <button type="submit" disabled={loading} style={{width:"100%",padding:12,background:"#2E5C7A",color:"#fff",border:"none",borderRadius:6,fontSize:14,fontWeight:600,cursor:"pointer",marginBottom:10}}>
        {loading?"Connecting to TaRMS...":"Connect to TaRMS & View My VAT"}
      </button>
      <button type="button" onClick={onRegister} style={{width:"100%",padding:12,background:"transparent",color:"#0f6e56",border:"1.5px solid #0f6e56",borderRadius:6,fontSize:14,fontWeight:600,cursor:"pointer"}}>
        Register My Business
      </button>
    </form>
    <div style={{marginTop:16,fontSize:11,color:"#888",textAlign:"center"}}>
      <div style={{color:"#c17d00",fontWeight:600}}>Sandbox mode — any password accepted</div>
      <div style={{marginTop:4}}>Demo TINs: 2003030303 · 2019012345 · 2020087654 · 2018003311</div>
    </div>
  </div>
  </div>)
}

function SessionTimer({token,onLogout}){
  const[remaining,setRemaining]=useState(null);
  const[extending,setExtending]=useState(false);
  const timerRef=useRef(null);
  const fetchRemaining=useCallback(async()=>{
    try{const r=await fetch(`http://localhost:5000/api/sme/dashboard`,{headers:{Authorization:`Bearer ${token}`}});
    if(r.status===401){onLogout();return;}
    const d=await r.json();
    if(d.session_remaining!==undefined)setRemaining(d.session_remaining);}
    catch{}
  },[token,onLogout]);
  useEffect(()=>{
    fetchRemaining();
    timerRef.current=setInterval(()=>setRemaining(r=>r!==null?Math.max(0,r-1):null),1000);
    return()=>clearInterval(timerRef.current);
  },[fetchRemaining]);
  useEffect(()=>{if(remaining===0)onLogout();},[remaining,onLogout]);
  const extend=async()=>{
    setExtending(true);
    try{const r=await fetch(`${API}/session/extend`,{method:"POST",headers:{Authorization:`Bearer ${token}`}});
    const d=await r.json();if(d.remaining)setRemaining(d.remaining);}
    catch{}finally{setExtending(false);}
  };
  if(remaining===null)return null;
  const urgent=remaining<300;
  return(<div style={{display:"flex",alignItems:"center",gap:6}}>
    <span style={{fontSize:11,color:urgent?"#f9c23c":"#8bbbd8",fontFamily:"monospace",background:urgent?"rgba(249,194,60,.15)":"transparent",padding:"2px 6px",borderRadius:4}}>
      ⏱ {fmtTime(remaining)}
    </span>
    {urgent&&<button onClick={extend} disabled={extending} style={{background:"#f9c23c",color:"#333",border:"none",padding:"3px 10px",borderRadius:4,cursor:"pointer",fontSize:11,fontWeight:700}}>
      {extending?"...":"Extend"}
    </button>}
  </div>);
}

function Dashboard({token,businessName,tin,onLogout}){
  const[period,setPeriod]=useState(currentPeriod());
  const[data,setData]=useState(null);
  const[loading,setLoading]=useState(true);
  const[error,setError]=useState("");
  const[tab,setTab]=useState("summary");
  const[txTab,setTxTab]=useState("all");
  const[comparison,setComparison]=useState(null);
  const[lastRefresh,setLastRefresh]=useState(null);

  const load=useCallback(async(p)=>{
    const target=p||period;
    setLoading(true);setError("");
    try{const r=await fetch(`${API}/dashboard?period=${target}`,{headers:{Authorization:`Bearer ${token}`}});
    if(r.status===401){onLogout();return;}
    const d=await r.json();
    if(!r.ok){setError(d.error||"Failed");return;}
    setData(d);setLastRefresh(new Date());}
    catch{setError("Cannot reach backend.");}
    finally{setLoading(false);}
  },[token,onLogout,period]);

  const loadComparison=useCallback(async()=>{
    try{const r=await fetch(`${API}/comparison`,{headers:{Authorization:`Bearer ${token}`}});
    if(!r.ok)return;
    const d=await r.json();setComparison(d.comparison||[]);}
    catch{}
  },[token]);

  useEffect(()=>{load(period);},[period]);
  useEffect(()=>{if(tab==="comparison")loadComparison();},[tab,loadComparison]);

  const changePeriod=p=>{setPeriod(p);};
  const records=data?.records||[];
  const typeLabel={IN:"INPUT",OUT:"OUTPUT",CREDIT_NOTE:"CREDIT NOTE",ADJUSTMENT:"ADJUSTMENT"};
  const typeColor={IN:"#0f6e56",OUT:"#c17d00",CREDIT_NOTE:"#533AB7",ADJUSTMENT:"#993C1D"};
  const shown=txTab==="all"?records:records.filter(r=>r.record_type===txTab);
  const s=data?.summary;
  const flags=data?.compliance_flags||[];

  const exportCSV=async()=>{
    const r=await fetch(`${API}/export/csv?period=${period}`,{headers:{Authorization:`Bearer ${token}`}});
    const blob=await r.blob();const url=URL.createObjectURL(blob);
    const a=document.createElement("a");a.href=url;a.download=`VATSync_VAT7_${tin}_${period}.csv`;a.click();URL.revokeObjectURL(url);
  };

  const navBtn={background:"transparent",border:"1px solid #4a8ab8",color:"#8bbbd8",padding:"2px 10px",borderRadius:4,cursor:"pointer",fontSize:13,fontWeight:700};

  return(<div style={{minHeight:"100vh",background:"#f0f6fb"}}>
  {/* Header */}
  <div style={{background:"#1a4f72",padding:"0 20px",display:"flex",alignItems:"center",height:52,gap:10}}>
    <div style={{display:"flex",alignItems:"center",gap:8}}>
      <SyncIcon size={22} color="#fff"/>
      <span style={{color:"#fff",fontWeight:700,fontSize:17}}>VATSync</span>
    </div>
    <span style={{color:"#4a8ab8",fontSize:12}}>|</span>
    <span style={{color:"#8bbbd8",fontSize:12,maxWidth:220,overflow:"hidden",textOverflow:"ellipsis",whiteSpace:"nowrap"}}>{businessName}</span>
    <span style={{color:"#5a7fa0",fontSize:10,fontFamily:"monospace"}}>TIN:{tin}</span>
    <div style={{marginLeft:"auto",display:"flex",gap:8,alignItems:"center"}}>
      <SessionTimer token={token} onLogout={onLogout}/>
      {lastRefresh&&<span style={{color:"#6a9ab8",fontSize:10}}>Updated {lastRefresh.toLocaleTimeString()}</span>}
      <button onClick={()=>load(period)} disabled={loading} style={{background:"transparent",border:"1px solid #8bbbd8",color:"#8bbbd8",padding:"3px 12px",borderRadius:4,cursor:"pointer",fontSize:11}}>
        {loading?"⟳":"⟳ Refresh"}
      </button>
      <button onClick={onLogout} style={{background:"transparent",border:"1px solid #f38b8b",color:"#f38b8b",padding:"3px 12px",borderRadius:4,cursor:"pointer",fontSize:11}}>Logout</button>
    </div>
  </div>

  <div style={{maxWidth:1280,margin:"0 auto",padding:"20px 18px"}}>
    {/* Period navigation */}
    <div style={{display:"flex",alignItems:"center",gap:10,marginBottom:18,flexWrap:"wrap"}}>
      <h2 style={{margin:0,color:"#1a4f72",fontSize:19}}>VAT Position</h2>
      <button onClick={()=>changePeriod(prevPeriod(period))} style={navBtn}>‹ Prev</button>
      <select value={period} onChange={e=>changePeriod(e.target.value)} style={{padding:"4px 10px",borderRadius:5,border:"1px solid #4a8ab8",fontSize:13,background:"#fff",color:"#1a4f72",fontWeight:600,cursor:"pointer"}}>
        {periodList().map(p=><option key={p} value={p}>{p}</option>)}
      </select>
      <button onClick={()=>changePeriod(nextPeriod(period))} style={navBtn}>Next ›</button>
      <span style={{fontSize:11,color:"#888",marginLeft:"auto"}}>{data?.record_count||0} transactions · TaRMS data</span>
    </div>

    {/* Main tabs */}
    <div style={{display:"flex",gap:4,marginBottom:16,borderBottom:"2px solid #d0dce8"}}>
      {[["summary","📊 Summary"],["transactions","📋 Transactions"],["compliance","🔍 Compliance"],["comparison","📈 Period Trend"]].map(([k,label])=>
        <button key={k} onClick={()=>setTab(k)} style={{padding:"8px 18px",background:tab===k?"#2E5C7A":"transparent",color:tab===k?"#fff":"#2E5C7A",border:"none",borderBottom:tab===k?"2px solid #2E5C7A":"2px solid transparent",cursor:"pointer",fontSize:13,fontWeight:tab===k?700:400,marginBottom:-2}}>
          {label}
        </button>
      )}
    </div>

    {error&&<div style={{background:"#fde8e8",border:"1px solid #c0392b",borderRadius:8,padding:"12px 16px",color:"#c0392b",marginBottom:16}}>{error}</div>}

    {/* SUMMARY TAB */}
    {tab==="summary"&&(loading&&!data?<div style={{textAlign:"center",padding:80,color:"#888"}}>Loading VAT position from TaRMS...</div>:s?<div>
      {/* USD KPI cards */}
      <div style={{fontSize:11,fontWeight:700,color:"#555",textTransform:"uppercase",letterSpacing:1,marginBottom:8}}>USD (Transaction Currency)</div>
      <div style={{display:"flex",gap:12,flexWrap:"wrap",marginBottom:14}}>
        {[
          {label:"Total Input Tax",value:s.total_input,sub:`${s.input_count} purchase records`,color:"#0f6e56"},
          {label:"Total Output Tax",value:s.total_output,sub:`${s.output_count} sales records`,color:"#c17d00"},
          {label:"Credit Notes",value:s.credit_notes,sub:`${s.credit_count||0} credits issued`,color:"#533AB7"},
          {label:"B/F Credit (Prior Period)",value:s.brought_forward_credit||0,sub:"Refund carried forward",color:"#1a6fa8"},
          {label:"Net VAT Liability (USD)",value:s.net_vat,sub:s.net_vat<0?"Refund due from ZIMRA":"Payable to ZIMRA",color:s.net_vat<0?"#0f6e56":"#c0392b"},
        ].map(card=><div key={card.label} style={{flex:"1 1 160px",padding:"14px 16px",border:`2px solid ${card.color}`,borderRadius:8,background:card.color+"14"}}>
          <div style={{fontSize:9,fontWeight:700,color:card.color,textTransform:"uppercase",letterSpacing:1,marginBottom:4}}>{card.label}</div>
          <div style={{fontSize:20,fontWeight:700,color:card.color,fontFamily:"monospace"}}>{card.value<0?"-":""}${fmt(Math.abs(card.value||0))}</div>
          <div style={{fontSize:10,color:"#666",marginTop:3}}>{card.sub}</div>
        </div>)}
      </div>
      {/* ZiG KPI cards */}
      <div style={{fontSize:11,fontWeight:700,color:"#555",textTransform:"uppercase",letterSpacing:1,marginBottom:8}}>ZiG / ZWG (ZIMRA Reporting Currency)</div>
      <div style={{display:"flex",gap:12,flexWrap:"wrap",marginBottom:20}}>
        {[
          {label:"Total Input Tax (ZiG)",value:s.total_input_zwg,color:"#0f6e56"},
          {label:"Total Output Tax (ZiG)",value:s.total_output_zwg,color:"#c17d00"},
          {label:"Credit Notes (ZiG)",value:s.credit_notes_zwg,color:"#533AB7"},
          {label:"Net VAT Liability (ZiG)",value:s.net_vat_zwg,sub:s.net_vat_zwg<0?"Refund due (ZiG)":"Payable to ZIMRA",color:s.net_vat_zwg<0?"#0f6e56":"#c0392b"},
        ].map(card=><div key={card.label} style={{flex:"1 1 180px",padding:"14px 16px",border:`1.5px solid ${card.color}88`,borderRadius:8,background:card.color+"0d"}}>
          <div style={{fontSize:9,fontWeight:700,color:card.color,textTransform:"uppercase",letterSpacing:1,marginBottom:4}}>{card.label}</div>
          <div style={{fontSize:20,fontWeight:700,color:card.color,fontFamily:"monospace"}}>{(card.value||0)<0?"-":""}ZiG {fmt(Math.abs(card.value||0))}</div>
          {card.sub&&<div style={{fontSize:10,color:"#666",marginTop:3}}>{card.sub}</div>}
        </div>)}
      </div>
      {/* VAT position banner */}
      <div style={{background:s.net_vat<0?"#d4edda":"#fff3cd",border:`1px solid ${s.net_vat<0?"#0f6e56":"#c17d00"}`,borderRadius:8,padding:"12px 16px",marginBottom:16,display:"flex",alignItems:"center",gap:12}}>
        <span style={{fontSize:18}}>{s.net_vat<0?"✅":"⚠️"}</span>
        <div>
          <div style={{fontWeight:700,color:s.net_vat<0?"#0f6e56":"#c17d00",fontSize:14}}>
            {s.net_vat<0?`ZIMRA OWES YOU $${fmt(Math.abs(s.net_vat))} (ZiG ${fmt(Math.abs(s.net_vat_zwg||0))})`:`YOU OWE ZIMRA $${fmt(s.net_vat)} (ZiG ${fmt(s.net_vat_zwg||0)})`}
          </div>
          <div style={{fontSize:11,color:"#666",marginTop:2}}>Submit VAT 7 on TaRMS portal by the 25th of the following month.</div>
        </div>
        <button onClick={exportCSV} style={{marginLeft:"auto",background:"#2E5C7A",color:"#fff",border:"none",padding:"8px 16px",borderRadius:6,cursor:"pointer",fontSize:12,fontWeight:600,whiteSpace:"nowrap"}}>⬇ Export VAT 7 CSV</button>
      </div>
    </div>:null)}

    {/* TRANSACTIONS TAB */}
    {tab==="transactions"&&<div>
      <div style={{display:"flex",gap:8,marginBottom:12,flexWrap:"wrap",alignItems:"center"}}>
        {["all","IN","OUT","CREDIT_NOTE","ADJUSTMENT"].map(t=><button key={t} onClick={()=>setTxTab(t)} style={{background:txTab===t?"#2E5C7A":"transparent",color:txTab===t?"#fff":"#2E5C7A",border:"1px solid #2E5C7A",padding:"3px 12px",borderRadius:10,cursor:"pointer",fontSize:11,fontWeight:txTab===t?700:400}}>
          {t==="all"?"All":t==="IN"?"Input":t==="OUT"?"Output":t==="CREDIT_NOTE"?"Credits":"Adjustments"}
        </button>)}
        <span style={{marginLeft:"auto",fontSize:11,color:"#888"}}>{shown.length} records</span>
      </div>
      <div style={{background:"#fff",borderRadius:8,border:"1px solid #d0dce8",overflowX:"auto"}}>
        <table style={{width:"100%",borderCollapse:"collapse",fontSize:11}}>
          <thead><tr style={{background:"#f5f8fb"}}>
            {["Date","Ref","Type","Counterparty / TIN","Ccy","Gross (Orig)","Gross (USD)","VAT (USD)","Rate","VAT (ZiG)","Status"].map(h=>
              <th key={h} style={{padding:"8px 10px",textAlign:"left",fontWeight:600,color:"#555",borderBottom:"1px solid #d0dce8",whiteSpace:"nowrap"}}>{h}</th>
            )}
          </tr></thead>
          <tbody>
            {shown.length===0?<tr><td colSpan={11} style={{padding:32,textAlign:"center",color:"#888"}}>No transactions for this period.</td></tr>:
            shown.map((r,i)=><tr key={r.fdms_ref} style={{background:i%2===0?"#fff":"#f9fbfd"}}>
              <td style={{padding:"6px 10px",whiteSpace:"nowrap"}}>{r.transaction_date}</td>
              <td style={{padding:"6px 10px",fontFamily:"monospace",fontSize:10,color:"#555"}}>{r.fdms_ref}</td>
              <td style={{padding:"6px 10px"}}>
                <span style={{background:(typeColor[r.record_type]||"#888")+"22",color:typeColor[r.record_type]||"#888",padding:"2px 7px",borderRadius:10,fontWeight:700,fontSize:9,whiteSpace:"nowrap"}}>
                  {typeLabel[r.record_type]||r.record_type}
                </span>
              </td>
              <td style={{padding:"6px 10px"}}>{r.counterparty_name}<br/><span style={{fontSize:9,color:"#888"}}>{r.counterparty_tin}</span></td>
              <td style={{padding:"6px 10px",fontWeight:700,color:r.currency==="ZWG"?"#533AB7":"#1a6fa8"}}>{r.currency||"USD"}</td>
              <td style={{padding:"6px 10px",fontFamily:"monospace",textAlign:"right"}}>{r.currency==="ZWG"?"ZiG ":""}{fmt(r.original_amount||r.gross_amount)}</td>
              <td style={{padding:"6px 10px",fontFamily:"monospace",textAlign:"right"}}>${fmt(r.gross_amount)}</td>
              <td style={{padding:"6px 10px",fontFamily:"monospace",textAlign:"right",color:typeColor[r.record_type]||"#333"}}>${fmt(r.tax_amount)}</td>
              <td style={{padding:"6px 10px",fontFamily:"monospace",textAlign:"right",fontSize:10,color:"#888"}}>{(r.exchange_rate||1).toFixed(2)}</td>
              <td style={{padding:"6px 10px",fontFamily:"monospace",textAlign:"right",color:"#533AB7"}}>ZiG {fmt(r.zwg_equivalent||r.tax_amount)}</td>
              <td style={{padding:"6px 10px"}}>
                <span style={{color:r.status==="ACTIVE"?"#0f6e56":"#c0392b",fontSize:10,fontWeight:600}}>
                  {r.status==="ACTIVE"?"✓ Active":"✕ Cancelled"}
                </span>
              </td>
            </tr>)}
          </tbody>
        </table>
      </div>
      <div style={{marginTop:10,fontSize:10,color:"#888",textAlign:"right"}}>Exchange rates: RBZ official interbank rate on transaction date.</div>
    </div>}

    {/* COMPLIANCE TAB */}
    {tab==="compliance"&&<div>
      <div style={{marginBottom:14}}>
        <div style={{fontWeight:700,color:"#1a4f72",marginBottom:4}}>Supplier Compliance — Matching Rule</div>
        <div style={{fontSize:12,color:"#666"}}>ZIMRA Matching Rule: every INPUT (purchase) you claim must have a corresponding OUTPUT posted by the supplier in the same period. Unmatched inputs may be disallowed.</div>
      </div>
      {flags.length===0?<div style={{background:"#d4edda",border:"1px solid #0f6e56",borderRadius:8,padding:20,textAlign:"center",color:"#0f6e56",fontWeight:600}}>
        ✅ All input records are compliant for {period}. No mismatches detected.
      </div>:<div>
        <div style={{background:"#fff3cd",border:"1px solid #c17d00",borderRadius:8,padding:"10px 14px",marginBottom:12,fontSize:12,color:"#7a5500"}}>
          ⚠️ {flags.length} compliance issue{flags.length>1?"s":""} detected for {period}. Review and resolve before submitting VAT 7.
        </div>
        <div style={{background:"#fff",borderRadius:8,border:"1px solid #d0dce8",overflowX:"auto"}}>
          <table style={{width:"100%",borderCollapse:"collapse",fontSize:12}}>
            <thead><tr style={{background:"#f5f8fb"}}>
              {["Ref","Date","Supplier","Supplier TIN","VAT Claimed (USD)","Issue","Action"].map(h=>
                <th key={h} style={{padding:"8px 12px",textAlign:"left",fontWeight:600,color:"#555",borderBottom:"1px solid #d0dce8"}}>{h}</th>
              )}
            </tr></thead>
            <tbody>
              {flags.map((f,i)=><tr key={f.fdms_ref} style={{background:i%2===0?"#fff":"#fffbf0"}}>
                <td style={{padding:"7px 12px",fontFamily:"monospace",fontSize:10}}>{f.fdms_ref}</td>
                <td style={{padding:"7px 12px"}}>{f.transaction_date}</td>
                <td style={{padding:"7px 12px",fontWeight:600}}>{f.counterparty_name}</td>
                <td style={{padding:"7px 12px",fontFamily:"monospace"}}>{f.counterparty_tin||"—"}</td>
                <td style={{padding:"7px 12px",fontFamily:"monospace",textAlign:"right",color:"#c0392b"}}>${fmt(f.tax_amount)}</td>
                <td style={{padding:"7px 12px"}}>
                  <span style={{background:"#fde8e822",color:"#c0392b",padding:"2px 8px",borderRadius:8,fontSize:10,fontWeight:700,whiteSpace:"nowrap"}}>
                    {f.flag==="NO_TIN"?"No Supplier TIN":f.flag==="UNREGISTERED"?"Supplier Unregistered":"No Matching Output"}
                  </span>
                </td>
                <td style={{padding:"7px 12px",fontSize:11,color:"#888"}}>
                  {f.flag==="NO_TIN"?"Request supplier TIN":f.flag==="UNREGISTERED"?"Verify supplier registration":"Contact supplier to file return"}
                </td>
              </tr>)}
            </tbody>
          </table>
        </div>
      </div>}
    </div>}

    {/* COMPARISON TAB */}
    {tab==="comparison"&&<div>
      <div style={{fontWeight:700,color:"#1a4f72",marginBottom:12}}>6-Period VAT Trend</div>
      {!comparison?<div style={{textAlign:"center",padding:40,color:"#888"}}>Loading comparison data...</div>:
      <div>
        <div style={{background:"#fff",borderRadius:8,border:"1px solid #d0dce8",overflowX:"auto",marginBottom:16}}>
          <table style={{width:"100%",borderCollapse:"collapse",fontSize:12}}>
            <thead><tr style={{background:"#f5f8fb"}}>
              {["Period","Input Tax (USD)","Output Tax (USD)","Credit Notes","B/F Credit","Net VAT (USD)","Net VAT (ZiG)","Status"].map(h=>
                <th key={h} style={{padding:"9px 12px",textAlign:"left",fontWeight:600,color:"#555",borderBottom:"1px solid #d0dce8",whiteSpace:"nowrap"}}>{h}</th>
              )}
            </tr></thead>
            <tbody>
              {comparison.map((row,i)=><tr key={row.period} style={{background:row.period===period?"#eaf4fb":i%2===0?"#fff":"#f9fbfd"}}>
                <td style={{padding:"8px 12px",fontWeight:row.period===period?700:400,color:row.period===period?"#1a4f72":"#333"}}>
                  {row.period}{row.period===period&&<span style={{fontSize:9,marginLeft:6,color:"#1a6fa8",fontWeight:700}}>CURRENT</span>}
                </td>
                <td style={{padding:"8px 12px",fontFamily:"monospace",textAlign:"right",color:"#0f6e56"}}>${fmt(row.total_input||0)}</td>
                <td style={{padding:"8px 12px",fontFamily:"monospace",textAlign:"right",color:"#c17d00"}}>${fmt(row.total_output||0)}</td>
                <td style={{padding:"8px 12px",fontFamily:"monospace",textAlign:"right",color:"#533AB7"}}>${fmt(row.credit_notes||0)}</td>
                <td style={{padding:"8px 12px",fontFamily:"monospace",textAlign:"right",color:"#1a6fa8"}}>${fmt(row.brought_forward_credit||0)}</td>
                <td style={{padding:"8px 12px",fontFamily:"monospace",textAlign:"right",fontWeight:700,color:(row.net_vat||0)<0?"#0f6e56":"#c0392b"}}>
                  {(row.net_vat||0)<0?"-":""}${fmt(Math.abs(row.net_vat||0))}
                </td>
                <td style={{padding:"8px 12px",fontFamily:"monospace",textAlign:"right",color:"#533AB7"}}>ZiG {fmt(row.net_vat_zwg||0)}</td>
                <td style={{padding:"8px 12px"}}>
                  {row.total_input===0&&row.total_output===0
                    ?<span style={{color:"#aaa",fontSize:10}}>No data</span>
                    :(row.net_vat||0)<0
                      ?<span style={{color:"#0f6e56",fontWeight:600,fontSize:10}}>REFUND</span>
                      :<span style={{color:"#c0392b",fontWeight:600,fontSize:10}}>PAYABLE</span>}
                </td>
              </tr>)}
            </tbody>
          </table>
        </div>
        {/* Simple bar visual */}
        <div style={{background:"#fff",borderRadius:8,border:"1px solid #d0dce8",padding:16}}>
          <div style={{fontSize:11,fontWeight:700,color:"#555",marginBottom:10}}>Net VAT Trend (USD)</div>
          <div style={{display:"flex",gap:6,alignItems:"flex-end",height:100}}>
            {[...comparison].reverse().map(row=>{
              const max=Math.max(...comparison.map(r=>Math.abs(r.net_vat||0)),1);
              const h=Math.round((Math.abs(row.net_vat||0)/max)*90);
              const pos=(row.net_vat||0)>=0;
              return<div key={row.period} style={{flex:1,display:"flex",flexDirection:"column",alignItems:"center",gap:3}}>
                <div style={{fontSize:9,color:pos?"#c0392b":"#0f6e56",fontWeight:700,fontFamily:"monospace"}}>${fmt(Math.abs(row.net_vat||0))}</div>
                <div style={{width:"100%",height:h||4,background:pos?"#e8a0a0":"#a0d8b0",borderRadius:"3px 3px 0 0",minHeight:4}}/>
                <div style={{fontSize:9,color:"#888",textAlign:"center",lineHeight:1.2}}>{row.period?.slice(5)}</div>
              </div>
            })}
          </div>
          <div style={{display:"flex",gap:12,marginTop:10,fontSize:10,color:"#888"}}>
            <span><span style={{color:"#c0392b"}}>■</span> Payable to ZIMRA</span>
            <span><span style={{color:"#0f6e56"}}>■</span> Refund from ZIMRA</span>
          </div>
        </div>
      </div>}
    </div>}
  </div>
  </div>)
}

export default function App(){
  const[screen,setScreen]=useState("login");
  const[auth,setAuth]=useState(null);
  const handleLogin=(token,businessName,tin,period)=>{setAuth({token,businessName,tin,period});setScreen("dashboard")};
  const handleLogout=useCallback(async()=>{
    if(auth?.token)try{await fetch(`${API}/logout`,{method:"POST",headers:{Authorization:`Bearer ${auth.token}`}});}catch{}
    setAuth(null);setScreen("login");
  },[auth]);
  if(screen==="dashboard"&&auth)return<Dashboard {...auth} onLogout={handleLogout}/>;
  if(screen==="register")return<RegisterScreen onBack={()=>setScreen("login")}/>;
  return<LoginScreen onLogin={handleLogin} onRegister={()=>setScreen("register")}/>;
}
