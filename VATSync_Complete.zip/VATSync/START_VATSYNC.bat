@echo off
echo ============================================================
echo   VATSync -- Real-Time VAT Reconciliation System
echo   Integrated with ZIMRA TaRMS (Fiscal Data Management)
echo ============================================================
echo.
echo Starting Flask Backend on port 5000...
start "VATSync Backend API" cmd /k "cd /d %~dp0backend && venv\Scripts\activate && python app.py"
timeout /t 3 /nobreak > nul

echo Starting SME Portal on port 3000...
start "VATSync SME Portal" cmd /k "cd /d %~dp0sme-frontend && npm run dev"
timeout /t 3 /nobreak > nul

echo Starting ZIMRA TaRMS Panel on port 3001...
start "VATSync ZIMRA Panel" cmd /k "cd /d %~dp0zimra-frontend && npm run dev"
timeout /t 5 /nobreak > nul

echo Opening SME Portal...
start http://localhost:3000
timeout /t 2 /nobreak > nul

echo Opening ZIMRA TaRMS Administration Panel...
start http://localhost:3001

echo.
echo ============================================================
echo   VATSync SME Portal:    http://localhost:3000
echo   VATSync ZIMRA Panel:   http://localhost:3001
echo   VATSync Backend API:   http://localhost:5000
echo   Health Check:          http://localhost:5000/api/health
echo ============================================================
echo.
echo Demo SME TINs: 2003030303  2019012345  2020087654  2018003311
echo ZIMRA Login:   zimra_admin / zimra2026
echo.
echo Close the three black command windows to stop all servers.
pause
