import{useState,useEffect,useCallback}from"react";
const API="http://localhost:5000/api/zimra";
const RATES_API="http://localhost:5000/api";
const fmt=n=>typeof n==="number"?n.toLocaleString("en-US",{minimumFractionDigits:2,maximumFractionDigits:2}):"0.00";
const currentPeriod=()=>{const d=new Date();return`${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,"0")}`};
const periods=()=>{const l=[];const n=new Date();for(let i=0;i<12;i++){const d=new Date(n.getFullYear(),n.getMonth()-i,1);l.push(`${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,"0")}`)}return l};

const RECORD_TYPES=[
  {value:"OUT",label:"Sales Invoice (Output Tax — VAT charged on sales)"},
  {value:"IN", label:"Purchase Invoice (Input Tax — VAT paid on purchases)"},
  {value:"CREDIT_NOTE",label:"Credit Note (Reduces output tax liability)"},
  {value:"ADJUSTMENT",label:"Tax Adjustment (Manual adjustment to VAT position)"},
];
const TYPE_COLOR={IN:"#0f6e56",OUT:"#c17d00",CREDIT_NOTE:"#533AB7",ADJUSTMENT:"#993C1D"};
const TYPE_LABEL={IN:"PURCHASE",OUT:"SALES",CREDIT_NOTE:"CREDIT NOTE",ADJUSTMENT:"ADJUSTMENT"};
const inp={width:"100%",padding:"10px 12px",fontSize:13,border:"1.5px solid #d0dce8",borderRadius:6,boxSizing:"border-box",fontFamily:"inherit"};

const SyncIcon=({size=22,color="#fff"})=>(
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round">
    <path d="M23 4v6h-6"/>
    <path d="M1 20v-6h6"/>
    <path d="M3.51 9a9 9 0 0 1 14.85-3.36L23 10M1 14l4.64 4.36A9 9 0 0 0 20.49 15"/>
  </svg>
);

function LoginScreen({onLogin}){
  const[u,setU]=useState("zimra_admin");
  const[p,setP]=useState("");
  const[loading,setLoading]=useState(false);
  const[error,setError]=useState("");
  const submit=async e=>{
    e.preventDefault();setLoading(true);setError("");
    try{const r=await fetch(`${API}/login`,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({username:u,password:p})});
    const d=await r.json();
    if(!r.ok){setError(d.error||"Login failed");return;}
    onLogin(d.token,d.officer);}
    catch{setError("Cannot reach backend server.");}
    finally{setLoading(false);}
  };
  return(<div style={{minHeight:"100vh",background:"#0d1b2a",display:"flex",alignItems:"center",justifyContent:"center"}}>
  <div style={{background:"#1a2d44",borderRadius:12,padding:"40px 36px",width:420,boxShadow:"0 8px 32px rgba(0,0,0,.4)",border:"1px solid #2E5C7A"}}>
    <div style={{textAlign:"center",marginBottom:32}}>
      <div style={{display:"flex",alignItems:"center",justifyContent:"center",gap:8,marginBottom:8}}>
        <div style={{background:"#2E5C7A",borderRadius:8,padding:"6px 8px",display:"flex"}}><SyncIcon size={20} color="#4a9fd4"/></div>
        <div style={{fontSize:20,fontWeight:700,color:"#fff"}}>VATSync</div>
      </div>
      <div style={{fontSize:11,color:"#4a8ab5",fontWeight:600,letterSpacing:2,textTransform:"uppercase",marginBottom:4}}>Zimbabwe Revenue Authority</div>
      <div style={{fontSize:17,fontWeight:700,color:"#fff"}}>TaRMS Administration Panel</div>
      <div style={{fontSize:12,color:"#8bbbd8",marginTop:4}}>Authorised Officers Only</div>
    </div>
    <form onSubmit={submit}>
      <label style={{fontSize:12,fontWeight:600,color:"#8bbbd8",display:"block",marginBottom:4}}>Officer Username</label>
      <input style={{...inp,background:"#0d1b2a",color:"#fff",border:"1.5px solid #2E5C7A",marginBottom:14}} value={u} onChange={e=>setU(e.target.value)} required/>
      <label style={{fontSize:12,fontWeight:600,color:"#8bbbd8",display:"block",marginBottom:4}}>Password</label>
      <input style={{...inp,background:"#0d1b2a",color:"#fff",border:"1.5px solid #2E5C7A",marginBottom:20}} type="password" value={p} onChange={e=>setP(e.target.value)} required/>
      {error&&<div style={{background:"#4a1a1a",border:"1px solid #c0392b",borderRadius:6,padding:"10px 12px",fontSize:13,color:"#f38b8b",marginBottom:14}}>{error}</div>}
      <button type="submit" disabled={loading} style={{width:"100%",padding:13,background:"#2E5C7A",color:"#fff",border:"none",borderRadius:6,fontSize:14,fontWeight:600,cursor:"pointer"}}>
        {loading?"Authenticating...":"Login to TaRMS"}
      </button>
    </form>
    <div style={{marginTop:20,fontSize:11,color:"#4a6a8a",textAlign:"center"}}>
      This system is monitored. All actions are logged and audited.
    </div>
  </div>
  </div>)
}

function Panel({token,officer,onLogout}){
  const[tab,setTab]=useState("overview");
  const[businesses,setBusinesses]=useState([]);
  const[selectedTIN,setSelectedTIN]=useState("");
  const[period,setPeriod]=useState(currentPeriod());
  const[txList,setTxList]=useState([]);
  const[txLoading,setTxLoading]=useState(false);
  const[overview,setOverview]=useState(null);
  const[overviewLoading,setOverviewLoading]=useState(false);
  const[rates,setRates]=useState([]);
  const[rateForm,setRateForm]=useState({rate_date:new Date().toISOString().slice(0,10),usd_to_zwg:"",source:"RBZ Official"});
  const[rateMsg,setRateMsg]=useState({text:"",ok:false});
  const[form,setForm]=useState({tin_number:"",record_type:"OUT",currency:"USD",gross_amount:"",transaction_date:new Date().toISOString().slice(0,10),counterparty_name:"",counterparty_tin:"",invoice_number:"",description:""});
  const[posting,setPosting]=useState(false);
  const[msg,setMsg]=useState({text:"",ok:false});
  const[summary,setSummary]=useState(null);
  const[auditLogs,setAuditLogs]=useState([]);
  const[complianceData,setComplianceData]=useState(null);

  const headers=useCallback(()=>({"Authorization":`Bearer ${token}`,"Content-Type":"application/json"}),[token]);

  useEffect(()=>{
    fetch(`${API}/businesses`,{headers:headers()}).then(r=>r.json()).then(d=>setBusinesses(d.businesses||[])).catch(()=>{});
    fetch(`${RATES_API}/rates`).then(r=>r.json()).then(d=>setRates(d.rates||[])).catch(()=>{});
  },[token]);

  const loadOverview=useCallback(async()=>{
    setOverviewLoading(true);
    try{const r=await fetch(`${API}/overview?period=${period}`,{headers:headers()});
    const d=await r.json();setOverview(d);}
    catch{}finally{setOverviewLoading(false);}
  },[period,token]);

  useEffect(()=>{if(tab==="overview")loadOverview();},[tab,period,loadOverview]);

  const loadTx=useCallback(async()=>{
    if(!selectedTIN)return;
    setTxLoading(true);
    try{
      const[txR,sumR]=await Promise.all([
        fetch(`${API}/transactions?tin=${selectedTIN}&period=${period}`,{headers:headers()}),
        fetch(`${API}/summary/${selectedTIN}/${period}`,{headers:headers()})
      ]);
      const txD=await txR.json();const sumD=await sumR.json();
      setTxList(txD.transactions||[]);setSummary(sumD);
    }catch{}finally{setTxLoading(false);}
  },[selectedTIN,period,token]);

  useEffect(()=>{loadTx();},[loadTx]);

  const loadAudit=useCallback(async()=>{
    try{const r=await fetch(`${API}/audit`,{headers:headers()});const d=await r.json();setAuditLogs(d.logs||[]);}
    catch{}
  },[token]);

  useEffect(()=>{if(tab==="audit")loadAudit();},[tab,loadAudit]);

  const postTx=async e=>{
    e.preventDefault();setPosting(true);setMsg({text:"",ok:false});
    try{
      const r=await fetch(`${API}/transaction`,{method:"POST",headers:headers(),body:JSON.stringify({...form,gross_amount:parseFloat(form.gross_amount)})});
      const d=await r.json();
      if(!r.ok){setMsg({text:d.error||"Failed",ok:false});return;}
      setMsg({text:`✅ Posted! Ref: ${d.fdms_ref} | VAT: $${(d.vat_amount||0).toFixed(2)} | ZiG: ${(d.zwg_equivalent||0).toFixed(2)} → ${d.business_name}`,ok:true});
      setForm(f=>({...f,gross_amount:"",invoice_number:"",description:"",counterparty_name:"",counterparty_tin:""}));
      if(form.tin_number===selectedTIN)loadTx();
    }catch{setMsg({text:"Cannot reach server",ok:false});}
    finally{setPosting(false);}
  };

  const cancelTx=async(fdmsRef,tin)=>{
    if(!window.confirm(`Cancel transaction ${fdmsRef}?`))return;
    const r=await fetch(`${API}/transaction/${fdmsRef}?tin=${tin}`,{method:"DELETE",headers:headers()});
    const d=await r.json();alert(d.message||d.error);loadTx();
  };

  const saveRate=async e=>{
    e.preventDefault();setRateMsg({text:"",ok:false});
    try{const r=await fetch(`${API}/rates`,{method:"POST",headers:headers(),body:JSON.stringify({...rateForm,usd_to_zwg:parseFloat(rateForm.usd_to_zwg)})});
    const d=await r.json();
    if(!r.ok){setRateMsg({text:d.error||"Failed",ok:false});return;}
    setRateMsg({text:`✅ Rate saved: 1 USD = ${rateForm.usd_to_zwg} ZiG for ${rateForm.rate_date}`,ok:true});
    fetch(`${RATES_API}/rates`).then(r=>r.json()).then(d=>setRates(d.rates||[])).catch(()=>{});}
    catch{setRateMsg({text:"Cannot reach server",ok:false});}
  };

  const navBtn=(id,label)=><button key={id} onClick={()=>setTab(id)} style={{padding:"10px 18px",background:tab===id?"#2E5C7A":"transparent",color:tab===id?"#fff":"#8bbbd8",border:"none",cursor:"pointer",fontSize:12,fontWeight:tab===id?700:400,borderBottom:tab===id?"3px solid #4a9fd4":"3px solid transparent"}}>{label}</button>;

  return(<div style={{minHeight:"100vh",background:"#0d1b2a"}}>
  {/* Header */}
  <div style={{background:"#0a1520",borderBottom:"1px solid #1e3a52",padding:"0 20px",display:"flex",alignItems:"center",height:56,gap:10}}>
    <div style={{display:"flex",alignItems:"center",gap:8}}>
      <div style={{background:"#2E5C7A",borderRadius:6,padding:"4px 6px",display:"flex"}}><SyncIcon size={18} color="#4a9fd4"/></div>
      <div>
        <div style={{fontSize:10,color:"#4a8ab5",fontWeight:600,letterSpacing:1,textTransform:"uppercase",lineHeight:1}}>VATSync · ZIMRA TaRMS</div>
        <div style={{fontSize:14,fontWeight:700,color:"#fff",lineHeight:1.3}}>Administration Panel</div>
      </div>
    </div>
    <div style={{marginLeft:"auto",display:"flex",gap:10,alignItems:"center"}}>
      <span style={{fontSize:11,color:"#8bbbd8",background:"#1a2d44",padding:"3px 10px",borderRadius:10}}>Officer: {officer}</span>
      <button onClick={onLogout} style={{background:"transparent",border:"1px solid #c0392b",color:"#f38b8b",padding:"4px 14px",borderRadius:4,cursor:"pointer",fontSize:11}}>Logout</button>
    </div>
  </div>

  {/* Tabs */}
  <div style={{background:"#0a1520",borderBottom:"1px solid #1e3a52",padding:"0 20px",display:"flex",gap:2,overflowX:"auto"}}>
    {[["overview","📊 Overview"],["post","📝 Post Transaction"],["view","📋 Transactions"],["businesses","🏢 Businesses"],["rates","💱 Exchange Rates"],["audit","📁 Audit Log"]].map(([k,l])=>navBtn(k,l))}
  </div>

  <div style={{maxWidth:1280,margin:"0 auto",padding:"20px 18px"}}>

    {/* ── OVERVIEW ── */}
    {tab==="overview"&&<div>
      <div style={{display:"flex",alignItems:"center",gap:12,marginBottom:18,flexWrap:"wrap"}}>
        <h2 style={{color:"#fff",margin:0,fontSize:18}}>VAT Position Overview</h2>
        <select style={{...inp,background:"#1a2d44",color:"#fff",border:"1px solid #2E5C7A",width:"auto"}} value={period} onChange={e=>setPeriod(e.target.value)}>
          {periods().map(p=><option key={p} value={p}>{p}</option>)}
        </select>
        <button onClick={loadOverview} style={{background:"#2E5C7A",color:"#fff",border:"none",padding:"8px 16px",borderRadius:6,cursor:"pointer",fontSize:12}}>
          {overviewLoading?"Loading...":"🔄 Refresh"}
        </button>
      </div>
      {overview&&<div>
        {/* Totals banner */}
        <div style={{display:"flex",gap:12,flexWrap:"wrap",marginBottom:20}}>
          {[
            {label:"Total Payable (All SMEs)",value:overview.total_payable,color:"#c0392b"},
            {label:"Total Refunds Due",value:overview.total_refunds,color:"#0f6e56"},
            {label:"Registered SMEs",value:overview.sme_count,isCount:true,color:"#4a9fd4"},
            {label:"With Transactions",value:overview.with_transactions,isCount:true,color:"#c17d00"},
          ].map(c=><div key={c.label} style={{flex:"1 1 180px",background:"#1a2d44",border:`1px solid ${c.color}66`,borderRadius:8,padding:"14px 16px"}}>
            <div style={{fontSize:9,fontWeight:700,color:c.color,textTransform:"uppercase",letterSpacing:1,marginBottom:4}}>{c.label}</div>
            <div style={{fontSize:22,fontWeight:700,color:c.color,fontFamily:"monospace"}}>
              {c.isCount?c.value||0:`$${fmt(c.value||0)}`}
            </div>
          </div>)}
        </div>
        {/* Per-SME table */}
        <div style={{background:"#1a2d44",borderRadius:8,border:"1px solid #2E5C7A",overflowX:"auto"}}>
          <div style={{padding:"12px 16px",borderBottom:"1px solid #2E5C7A",color:"#fff",fontWeight:700}}>All SME Positions — {period}</div>
          <table style={{width:"100%",borderCollapse:"collapse",fontSize:12}}>
            <thead><tr style={{background:"#0d1b2a"}}>
              {["TIN","Business","Input (USD)","Output (USD)","Credit Notes","B/F Credit","Net VAT (USD)","Net VAT (ZiG)","Status","Flags"].map(h=>
                <th key={h} style={{padding:"8px 12px",textAlign:"left",color:"#8bbbd8",fontWeight:600,borderBottom:"1px solid #2E5C7A",whiteSpace:"nowrap"}}>{h}</th>
              )}
            </tr></thead>
            <tbody>
              {(overview.positions||[]).length===0
                ?<tr><td colSpan={10} style={{padding:32,textAlign:"center",color:"#4a6a8a"}}>No SME data for {period}</td></tr>
                :(overview.positions||[]).map((p,i)=><tr key={p.tin_number} style={{background:i%2===0?"#1a2d44":"#162438"}}>
                  <td style={{padding:"7px 12px",fontFamily:"monospace",color:"#4a9fd4",fontWeight:600}}>{p.tin_number}</td>
                  <td style={{padding:"7px 12px",color:"#fff"}}>{p.business_name}</td>
                  <td style={{padding:"7px 12px",fontFamily:"monospace",textAlign:"right",color:"#0f6e56"}}>${fmt(p.total_input||0)}</td>
                  <td style={{padding:"7px 12px",fontFamily:"monospace",textAlign:"right",color:"#c17d00"}}>${fmt(p.total_output||0)}</td>
                  <td style={{padding:"7px 12px",fontFamily:"monospace",textAlign:"right",color:"#533AB7"}}>${fmt(p.credit_notes||0)}</td>
                  <td style={{padding:"7px 12px",fontFamily:"monospace",textAlign:"right",color:"#4a9fd4"}}>${fmt(p.brought_forward_credit||0)}</td>
                  <td style={{padding:"7px 12px",fontFamily:"monospace",textAlign:"right",fontWeight:700,color:(p.net_vat||0)<0?"#0f6e56":"#c0392b"}}>
                    {(p.net_vat||0)<0?"-":""}${fmt(Math.abs(p.net_vat||0))}
                  </td>
                  <td style={{padding:"7px 12px",fontFamily:"monospace",textAlign:"right",color:"#a78bfa"}}>ZiG {fmt(p.net_vat_zwg||0)}</td>
                  <td style={{padding:"7px 12px"}}>
                    {p.total_input===0&&p.total_output===0
                      ?<span style={{color:"#4a6a8a",fontSize:10}}>NIL</span>
                      :(p.net_vat||0)<0
                        ?<span style={{color:"#0f6e56",fontWeight:700,fontSize:10}}>REFUND</span>
                        :<span style={{color:"#c0392b",fontWeight:700,fontSize:10}}>PAYABLE</span>}
                  </td>
                  <td style={{padding:"7px 12px"}}>
                    {(p.compliance_issues||0)>0
                      ?<span style={{color:"#f59e0b",fontSize:10,fontWeight:700}}>⚠ {p.compliance_issues}</span>
                      :<span style={{color:"#0f6e56",fontSize:10}}>✓</span>}
                  </td>
                </tr>)}
            </tbody>
          </table>
        </div>
      </div>}
    </div>}

    {/* ── POST TRANSACTION ── */}
    {tab==="post"&&<div>
      <h2 style={{color:"#fff",margin:"0 0 20px",fontSize:18}}>Post Transaction to Taxpayer Ledger</h2>
      <div style={{display:"flex",gap:20,flexWrap:"wrap"}}>
        <div style={{flex:1,minWidth:320,background:"#1a2d44",borderRadius:10,padding:24,border:"1px solid #2E5C7A"}}>
          <form onSubmit={postTx}>
            <label style={{fontSize:12,fontWeight:600,color:"#8bbbd8",display:"block",marginBottom:4}}>Taxpayer TIN *</label>
            <select style={{...inp,background:"#0d1b2a",color:"#fff",border:"1.5px solid #2E5C7A",marginBottom:14}}
              value={form.tin_number} onChange={e=>setForm(f=>({...f,tin_number:e.target.value}))} required>
              <option value="">— Select a registered business —</option>
              {businesses.map(b=><option key={b.tin_number} value={b.tin_number}>{b.tin_number} — {b.business_name}</option>)}
            </select>

            <label style={{fontSize:12,fontWeight:600,color:"#8bbbd8",display:"block",marginBottom:4}}>Transaction Type *</label>
            <select style={{...inp,background:"#0d1b2a",color:"#fff",border:"1.5px solid #2E5C7A",marginBottom:14}}
              value={form.record_type} onChange={e=>setForm(f=>({...f,record_type:e.target.value}))} required>
              {RECORD_TYPES.map(t=><option key={t.value} value={t.value}>{t.label}</option>)}
            </select>

            {/* Currency field — new */}
            <label style={{fontSize:12,fontWeight:600,color:"#8bbbd8",display:"block",marginBottom:4}}>Invoice Currency *</label>
            <select style={{...inp,background:"#0d1b2a",color:"#fff",border:"1.5px solid #2E5C7A",marginBottom:4}}
              value={form.currency} onChange={e=>setForm(f=>({...f,currency:e.target.value}))} required>
              <option value="USD">USD — United States Dollar</option>
              <option value="ZWG">ZWG / ZiG — Zimbabwe Gold</option>
            </select>
            <div style={{fontSize:11,color:"#4a9fd4",marginBottom:14}}>
              {form.currency==="USD"
                ?"Enter the USD amount. RBZ rate on transaction date will be used for ZiG equivalent."
                :"Enter the ZWG amount. System will back-calculate USD at RBZ rate on transaction date."}
            </div>

            <div style={{display:"flex",gap:12,marginBottom:14}}>
              <div style={{flex:1}}>
                <label style={{fontSize:12,fontWeight:600,color:"#8bbbd8",display:"block",marginBottom:4}}>
                  Gross Amount ({form.currency} incl. VAT) *
                </label>
                <input style={{...inp,background:"#0d1b2a",color:"#fff",border:"1.5px solid #2E5C7A"}}
                  type="number" step="0.01" min="0.01" value={form.gross_amount}
                  onChange={e=>setForm(f=>({...f,gross_amount:e.target.value}))} placeholder={form.currency==="USD"?"e.g. 11800.00":"e.g. 322900.00"} required/>
                {form.gross_amount&&parseFloat(form.gross_amount)>0&&
                  <div style={{fontSize:11,color:"#4a9fd4",marginTop:4}}>
                    VAT (15%): {form.currency==="USD"?"$":""}{(parseFloat(form.gross_amount)*0.15/1.15).toFixed(2)} {form.currency==="ZWG"?"ZiG":""}
                  </div>}
              </div>
              <div style={{flex:1}}>
                <label style={{fontSize:12,fontWeight:600,color:"#8bbbd8",display:"block",marginBottom:4}}>Transaction Date *</label>
                <input style={{...inp,background:"#0d1b2a",color:"#fff",border:"1.5px solid #2E5C7A"}}
                  type="date" value={form.transaction_date} max={new Date().toISOString().slice(0,10)}
                  onChange={e=>setForm(f=>({...f,transaction_date:e.target.value}))} required/>
              </div>
            </div>

            <label style={{fontSize:12,fontWeight:600,color:"#8bbbd8",display:"block",marginBottom:4}}>Counterparty Name *</label>
            <input style={{...inp,background:"#0d1b2a",color:"#fff",border:"1.5px solid #2E5C7A",marginBottom:14}}
              value={form.counterparty_name} onChange={e=>setForm(f=>({...f,counterparty_name:e.target.value}))}
              placeholder="e.g. Delta Beverages Ltd" required/>

            <div style={{display:"flex",gap:12,marginBottom:14}}>
              <div style={{flex:1}}>
                <label style={{fontSize:12,fontWeight:600,color:"#8bbbd8",display:"block",marginBottom:4}}>Counterparty TIN</label>
                <input style={{...inp,background:"#0d1b2a",color:"#fff",border:"1.5px solid #2E5C7A"}}
                  value={form.counterparty_tin} onChange={e=>setForm(f=>({...f,counterparty_tin:e.target.value.replace(/\D/g,"").slice(0,10)}))}
                  placeholder="10-digit TIN" maxLength={10}/>
              </div>
              <div style={{flex:1}}>
                <label style={{fontSize:12,fontWeight:600,color:"#8bbbd8",display:"block",marginBottom:4}}>Invoice Number</label>
                <input style={{...inp,background:"#0d1b2a",color:"#fff",border:"1.5px solid #2E5C7A"}}
                  value={form.invoice_number} onChange={e=>setForm(f=>({...f,invoice_number:e.target.value}))}
                  placeholder="Auto-generated if blank"/>
              </div>
            </div>

            <label style={{fontSize:12,fontWeight:600,color:"#8bbbd8",display:"block",marginBottom:4}}>Description</label>
            <input style={{...inp,background:"#0d1b2a",color:"#fff",border:"1.5px solid #2E5C7A",marginBottom:20}}
              value={form.description} onChange={e=>setForm(f=>({...f,description:e.target.value}))}
              placeholder="e.g. September 2026 sales invoice"/>

            {msg.text&&<div style={{background:msg.ok?"#0d2e1a":"#2e0d0d",border:`1px solid ${msg.ok?"#0f6e56":"#c0392b"}`,borderRadius:6,padding:"10px 12px",fontSize:11,color:msg.ok?"#4ade80":"#f87171",marginBottom:14}}>{msg.text}</div>}
            <button type="submit" disabled={posting} style={{width:"100%",padding:13,background:"#2E5C7A",color:"#fff",border:"none",borderRadius:6,fontSize:14,fontWeight:600,cursor:"pointer"}}>
              {posting?"Posting...":"Post Transaction to Taxpayer Ledger"}
            </button>
          </form>
        </div>

        <div style={{width:280,background:"#1a2d44",borderRadius:10,padding:20,border:"1px solid #2E5C7A",alignSelf:"flex-start"}}>
          <div style={{fontWeight:700,color:"#fff",marginBottom:14,fontSize:13}}>Dual-Currency Guide</div>
          <div style={{padding:"10px 12px",background:"#0d2a1a",borderRadius:6,marginBottom:12,border:"1px solid #0f6e56"}}>
            <div style={{fontSize:11,color:"#4ade80",fontWeight:700,marginBottom:4}}>USD Invoice</div>
            <div style={{fontSize:11,color:"#8bbbd8"}}>Select USD. Enter gross incl. VAT in USD. System applies RBZ rate on invoice date for ZiG equivalent on VAT 7.</div>
          </div>
          <div style={{padding:"10px 12px",background:"#0d1a2a",borderRadius:6,marginBottom:12,border:"1px solid #533AB7"}}>
            <div style={{fontSize:11,color:"#a78bfa",fontWeight:700,marginBottom:4}}>ZWG Invoice</div>
            <div style={{fontSize:11,color:"#8bbbd8"}}>Select ZWG. Enter gross in ZiG. System back-calculates USD at RBZ rate on invoice date.</div>
          </div>
          <div style={{padding:"10px 12px",background:"#1a1a0d",borderRadius:6,border:"1px solid #c17d00"}}>
            <div style={{fontSize:11,color:"#f9c23c",fontWeight:700,marginBottom:4}}>Parastatal Scenario</div>
            <div style={{fontSize:11,color:"#8bbbd8"}}>Quote in USD, paid in ZiG at RBZ rate on invoice date. Post as USD — system calculates ZiG equivalent automatically.</div>
          </div>
          {[...TYPE_LABEL].length&&<div style={{marginTop:14}}>
            {RECORD_TYPES.map(t=><div key={t.value} style={{marginBottom:8,padding:"8px 10px",background:"#0d1b2a",borderRadius:5,borderLeft:`3px solid ${TYPE_COLOR[t.value]}`}}>
              <div style={{fontSize:10,fontWeight:700,color:TYPE_COLOR[t.value],marginBottom:2}}>{TYPE_LABEL[t.value]}</div>
              <div style={{fontSize:10,color:"#8bbbd8"}}>{t.label.split("(")[0].trim()}</div>
            </div>)}
          </div>}
        </div>
      </div>
    </div>}

    {/* ── VIEW TRANSACTIONS ── */}
    {tab==="view"&&<div>
      <h2 style={{color:"#fff",margin:"0 0 16px",fontSize:18}}>Transaction Ledger</h2>
      <div style={{display:"flex",gap:12,marginBottom:16,flexWrap:"wrap",alignItems:"flex-end"}}>
        <div>
          <label style={{fontSize:12,color:"#8bbbd8",display:"block",marginBottom:4}}>Taxpayer TIN</label>
          <select style={{...inp,background:"#1a2d44",color:"#fff",border:"1.5px solid #2E5C7A",width:"auto",minWidth:280}}
            value={selectedTIN} onChange={e=>setSelectedTIN(e.target.value)}>
            <option value="">— Select a business —</option>
            {businesses.map(b=><option key={b.tin_number} value={b.tin_number}>{b.tin_number} — {b.business_name}</option>)}
          </select>
        </div>
        <div>
          <label style={{fontSize:12,color:"#8bbbd8",display:"block",marginBottom:4}}>VAT Period</label>
          <select style={{...inp,background:"#1a2d44",color:"#fff",border:"1.5px solid #2E5C7A",width:"auto"}}
            value={period} onChange={e=>setPeriod(e.target.value)}>
            {periods().map(p=><option key={p} value={p}>{p}</option>)}
          </select>
        </div>
        <button onClick={loadTx} style={{background:"#2E5C7A",color:"#fff",border:"none",padding:"10px 20px",borderRadius:6,cursor:"pointer",fontSize:13,marginBottom:1}}>
          {txLoading?"Loading...":"🔍 Load"}
        </button>
      </div>

      {summary&&selectedTIN&&<div>
        <div style={{display:"flex",gap:10,marginBottom:16,flexWrap:"wrap"}}>
          {[
            {label:"Input Tax (USD)",value:summary.summary?.total_input,color:"#0f6e56"},
            {label:"Output Tax (USD)",value:summary.summary?.total_output,color:"#c17d00"},
            {label:"Net VAT (USD)",value:summary.summary?.net_vat,color:(summary.summary?.net_vat||0)<0?"#0f6e56":"#c0392b"},
            {label:"Net VAT (ZiG)",value:summary.summary?.net_vat_zwg,color:"#a78bfa",prefix:"ZiG "},
          ].map(c=><div key={c.label} style={{flex:"1 1 140px",background:"#1a2d44",border:`1px solid ${c.color}55`,borderRadius:7,padding:"12px 14px"}}>
            <div style={{fontSize:9,color:c.color,fontWeight:700,textTransform:"uppercase",letterSpacing:1,marginBottom:3}}>{c.label}</div>
            <div style={{fontSize:18,fontWeight:700,color:c.color,fontFamily:"monospace"}}>
              {(c.value||0)<0?"-":""}{c.prefix||"$"}{fmt(Math.abs(c.value||0))}
            </div>
          </div>)}
        </div>
        {(summary.compliance_flags||[]).length>0&&<div style={{background:"#2a1a0d",border:"1px solid #c17d00",borderRadius:6,padding:"10px 14px",marginBottom:14,fontSize:12,color:"#f9c23c"}}>
          ⚠️ {summary.compliance_flags.length} compliance flag{summary.compliance_flags.length>1?"s":""} detected — {summary.compliance_flags.map(f=>f.counterparty_name).join(", ")}
        </div>}
        <div style={{background:"#1a2d44",borderRadius:8,border:"1px solid #2E5C7A",overflowX:"auto"}}>
          <div style={{padding:"10px 16px",borderBottom:"1px solid #2E5C7A",display:"flex",justifyContent:"space-between",alignItems:"center"}}>
            <span style={{color:"#fff",fontWeight:700,fontSize:13}}>{summary.business?.business_name} — {period}</span>
            <span style={{color:"#8bbbd8",fontSize:11}}>{txList.length} transactions</span>
          </div>
          <table style={{width:"100%",borderCollapse:"collapse",fontSize:11}}>
            <thead><tr style={{background:"#0d1b2a"}}>
              {["Date","Ref","Type","Counterparty","Ccy","Gross (Orig)","Gross (USD)","VAT (USD)","Rate","VAT (ZiG)","Posted By","Status","Action"].map(h=>
                <th key={h} style={{padding:"7px 10px",textAlign:"left",color:"#8bbbd8",fontWeight:600,borderBottom:"1px solid #2E5C7A",whiteSpace:"nowrap"}}>{h}</th>
              )}
            </tr></thead>
            <tbody>
              {txList.length===0?<tr><td colSpan={13} style={{padding:28,textAlign:"center",color:"#4a6a8a"}}>No transactions found.</td></tr>:
              txList.map((r,i)=><tr key={r.fdms_ref} style={{background:i%2===0?"#1a2d44":"#162438",opacity:r.status==="CANCELLED"?0.5:1}}>
                <td style={{padding:"6px 10px",color:"#ccc",whiteSpace:"nowrap"}}>{r.transaction_date}</td>
                <td style={{padding:"6px 10px",fontFamily:"monospace",fontSize:10,color:"#8bbbd8"}}>{r.fdms_ref}</td>
                <td style={{padding:"6px 10px"}}>
                  <span style={{background:(TYPE_COLOR[r.record_type]||"#888")+"33",color:TYPE_COLOR[r.record_type]||"#888",padding:"2px 7px",borderRadius:7,fontWeight:700,fontSize:9}}>
                    {TYPE_LABEL[r.record_type]||r.record_type}
                  </span>
                </td>
                <td style={{padding:"6px 10px",color:"#ccc"}}>{r.counterparty_name}</td>
                <td style={{padding:"6px 10px",fontWeight:700,color:r.currency==="ZWG"?"#a78bfa":"#4a9fd4"}}>{r.currency||"USD"}</td>
                <td style={{padding:"6px 10px",fontFamily:"monospace",textAlign:"right",color:"#ccc"}}>{fmt(r.original_amount||r.gross_amount)}</td>
                <td style={{padding:"6px 10px",fontFamily:"monospace",textAlign:"right",color:"#ccc"}}>${fmt(r.gross_amount)}</td>
                <td style={{padding:"6px 10px",fontFamily:"monospace",textAlign:"right",color:TYPE_COLOR[r.record_type]||"#ccc"}}>${fmt(r.tax_amount)}</td>
                <td style={{padding:"6px 10px",fontFamily:"monospace",textAlign:"right",fontSize:10,color:"#4a6a8a"}}>{(r.exchange_rate||1).toFixed(2)}</td>
                <td style={{padding:"6px 10px",fontFamily:"monospace",textAlign:"right",color:"#a78bfa"}}>ZiG {fmt(r.zwg_equivalent||r.tax_amount)}</td>
                <td style={{padding:"6px 10px",fontSize:10,color:"#4a9fd4"}}>{r.posted_by}</td>
                <td style={{padding:"6px 10px"}}>
                  <span style={{color:r.status==="ACTIVE"?"#4ade80":"#f87171",fontSize:10,fontWeight:600}}>{r.status==="ACTIVE"?"✓":"✕"}</span>
                </td>
                <td style={{padding:"6px 10px"}}>
                  {r.status==="ACTIVE"&&<button onClick={()=>cancelTx(r.fdms_ref,r.tin_number)} style={{background:"transparent",border:"1px solid #c0392b",color:"#f38b8b",padding:"2px 8px",borderRadius:4,cursor:"pointer",fontSize:10}}>
                    Cancel
                  </button>}
                </td>
              </tr>)}
            </tbody>
          </table>
        </div>
      </div>}
    </div>}

    {/* ── BUSINESSES ── */}
    {tab==="businesses"&&<div>
      <h2 style={{color:"#fff",margin:"0 0 16px",fontSize:18}}>Registered Businesses</h2>
      <div style={{background:"#1a2d44",borderRadius:8,border:"1px solid #2E5C7A",overflowX:"auto"}}>
        <table style={{width:"100%",borderCollapse:"collapse",fontSize:12}}>
          <thead><tr style={{background:"#0d1b2a"}}>
            {["TIN","Business Name","Email","Phone","Address","Transactions"].map(h=>
              <th key={h} style={{padding:"10px 14px",textAlign:"left",color:"#8bbbd8",fontWeight:600,borderBottom:"1px solid #2E5C7A"}}>{h}</th>
            )}
          </tr></thead>
          <tbody>
            {businesses.map((b,i)=><tr key={b.tin_number} style={{background:i%2===0?"#1a2d44":"#162438"}}>
              <td style={{padding:"9px 14px",fontFamily:"monospace",color:"#4a9fd4",fontWeight:600}}>{b.tin_number}</td>
              <td style={{padding:"9px 14px",color:"#fff"}}>{b.business_name}</td>
              <td style={{padding:"9px 14px",color:"#8bbbd8"}}>{b.email||"—"}</td>
              <td style={{padding:"9px 14px",color:"#8bbbd8"}}>{b.phone||"—"}</td>
              <td style={{padding:"9px 14px",color:"#8bbbd8",fontSize:11}}>{b.address||"—"}</td>
              <td style={{padding:"9px 14px",textAlign:"center"}}>
                <span style={{background:"#0d1b2a",color:"#4a9fd4",padding:"2px 10px",borderRadius:10,fontWeight:700,fontSize:11}}>{b.tx_count||0}</span>
              </td>
            </tr>)}
          </tbody>
        </table>
      </div>
    </div>}

    {/* ── EXCHANGE RATES ── */}
    {tab==="rates"&&<div>
      <h2 style={{color:"#fff",margin:"0 0 20px",fontSize:18}}>RBZ Exchange Rate Management</h2>
      <div style={{display:"flex",gap:20,flexWrap:"wrap"}}>
        <div style={{flex:"1 1 300px",background:"#1a2d44",borderRadius:10,padding:20,border:"1px solid #2E5C7A"}}>
          <div style={{fontWeight:700,color:"#fff",marginBottom:14}}>Add / Update Rate</div>
          <form onSubmit={saveRate}>
            <label style={{fontSize:12,fontWeight:600,color:"#8bbbd8",display:"block",marginBottom:4}}>Rate Date *</label>
            <input style={{...inp,background:"#0d1b2a",color:"#fff",border:"1.5px solid #2E5C7A",marginBottom:12}}
              type="date" value={rateForm.rate_date} onChange={e=>setRateForm(f=>({...f,rate_date:e.target.value}))} required/>
            <label style={{fontSize:12,fontWeight:600,color:"#8bbbd8",display:"block",marginBottom:4}}>USD to ZiG Rate *</label>
            <input style={{...inp,background:"#0d1b2a",color:"#fff",border:"1.5px solid #2E5C7A",marginBottom:4}}
              type="number" step="0.0001" min="0.0001" value={rateForm.usd_to_zwg}
              onChange={e=>setRateForm(f=>({...f,usd_to_zwg:e.target.value}))}
              placeholder="e.g. 27.55" required/>
            {rateForm.usd_to_zwg&&<div style={{fontSize:11,color:"#4a9fd4",marginBottom:12}}>1 USD = {rateForm.usd_to_zwg} ZiG</div>}
            <label style={{fontSize:12,fontWeight:600,color:"#8bbbd8",display:"block",marginBottom:4}}>Source</label>
            <input style={{...inp,background:"#0d1b2a",color:"#fff",border:"1.5px solid #2E5C7A",marginBottom:16}}
              value={rateForm.source} onChange={e=>setRateForm(f=>({...f,source:e.target.value}))}/>
            {rateMsg.text&&<div style={{background:rateMsg.ok?"#0d2e1a":"#2e0d0d",border:`1px solid ${rateMsg.ok?"#0f6e56":"#c0392b"}`,borderRadius:5,padding:"8px 12px",fontSize:11,color:rateMsg.ok?"#4ade80":"#f87171",marginBottom:12}}>{rateMsg.text}</div>}
            <button type="submit" style={{width:"100%",padding:12,background:"#2E5C7A",color:"#fff",border:"none",borderRadius:6,cursor:"pointer",fontWeight:600}}>
              Save Rate
            </button>
          </form>
        </div>
        <div style={{flex:"2 1 400px",background:"#1a2d44",borderRadius:10,border:"1px solid #2E5C7A",overflow:"hidden",alignSelf:"flex-start"}}>
          <div style={{padding:"12px 16px",borderBottom:"1px solid #2E5C7A",color:"#fff",fontWeight:700}}>Recent RBZ Rates (USD→ZiG)</div>
          <table style={{width:"100%",borderCollapse:"collapse",fontSize:12}}>
            <thead><tr style={{background:"#0d1b2a"}}>
              {["Date","Rate (ZiG/USD)","Source","Posted"].map(h=>
                <th key={h} style={{padding:"8px 14px",textAlign:"left",color:"#8bbbd8",fontWeight:600,borderBottom:"1px solid #2E5C7A"}}>{h}</th>
              )}
            </tr></thead>
            <tbody>
              {rates.slice(0,18).map((r,i)=><tr key={r.rate_id} style={{background:i%2===0?"#1a2d44":"#162438"}}>
                <td style={{padding:"7px 14px",color:"#ccc",fontFamily:"monospace"}}>{r.rate_date}</td>
                <td style={{padding:"7px 14px",fontFamily:"monospace",color:"#4ade80",fontWeight:700}}>1 USD = {r.usd_to_zwg} ZiG</td>
                <td style={{padding:"7px 14px",color:"#8bbbd8"}}>{r.source}</td>
                <td style={{padding:"7px 14px",color:"#4a6a8a",fontSize:10}}>{r.created_at?.slice(0,10)||"—"}</td>
              </tr>)}
            </tbody>
          </table>
        </div>
      </div>
    </div>}

    {/* ── AUDIT LOG ── */}
    {tab==="audit"&&<div>
      <h2 style={{color:"#fff",margin:"0 0 16px",fontSize:18}}>Audit Log</h2>
      <div style={{background:"#1a2d44",borderRadius:8,border:"1px solid #2E5C7A",overflowX:"auto"}}>
        <table style={{width:"100%",borderCollapse:"collapse",fontSize:11}}>
          <thead><tr style={{background:"#0d1b2a"}}>
            {["Time","Actor","Action","Result","Detail"].map(h=>
              <th key={h} style={{padding:"8px 12px",textAlign:"left",color:"#8bbbd8",fontWeight:600,borderBottom:"1px solid #2E5C7A",whiteSpace:"nowrap"}}>{h}</th>
            )}
          </tr></thead>
          <tbody>
            {auditLogs.length===0?<tr><td colSpan={5} style={{padding:32,textAlign:"center",color:"#4a6a8a"}}>No audit entries.</td></tr>:
            auditLogs.map((log,i)=><tr key={log.log_id} style={{background:i%2===0?"#1a2d44":"#162438"}}>
              <td style={{padding:"6px 12px",color:"#4a6a8a",fontFamily:"monospace",whiteSpace:"nowrap"}}>{log.timestamp}</td>
              <td style={{padding:"6px 12px",color:"#4a9fd4"}}>{log.actor}</td>
              <td style={{padding:"6px 12px",color:"#fff",fontWeight:600}}>{log.action}</td>
              <td style={{padding:"6px 12px"}}>
                <span style={{color:log.result==="SUCCESS"?"#4ade80":"#f87171",fontWeight:700,fontSize:10}}>{log.result}</span>
              </td>
              <td style={{padding:"6px 12px",color:"#8bbbd8"}}>{log.detail||"—"}</td>
            </tr>)}
          </tbody>
        </table>
      </div>
    </div>}

  </div>
  </div>)
}

export default function App(){
  const[auth,setAuth]=useState(null);
  const handleLogin=(token,officer)=>setAuth({token,officer});
  const handleLogout=async()=>{
    if(auth?.token)try{await fetch(`${API}/logout`,{method:"POST",headers:{Authorization:`Bearer ${auth.token}`}});}catch{}
    setAuth(null);
  };
  return auth?<Panel {...auth} onLogout={handleLogout}/>:<LoginScreen onLogin={handleLogin}/>;
}
